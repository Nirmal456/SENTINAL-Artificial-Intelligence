"""
SENTINEL-AI Backend
FastAPI application with WebSocket support for real-time communication.
"""
import asyncio
import json
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from config import config
from websocket import manager
from services.orchestrator import orchestrator


# ==========================================
# Lifespan Management
# ==========================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle"""
    print("=" * 50)
    print("SENTINEL-AI Starting...")
    print("=" * 50)
    
    # Start all agents
    await orchestrator.start()
    
    yield
    
    # Stop all agents
    await orchestrator.stop()
    
    print("=" * 50)
    print("SENTINEL-AI Stopped")
    print("=" * 50)


# ==========================================
# FastAPI App
# ==========================================

app = FastAPI(
    title="SENTINEL-AI",
    description="Autonomous Incident Management System",
    version="1.0.0",
    lifespan=lifespan
)

# CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all for development
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==========================================
# Request/Response Models
# ==========================================

class ApprovalRequest(BaseModel):
    incident_id: str


class RejectRequest(BaseModel):
    incident_id: str
    reason: Optional[str] = ""


class ModifyRequest(BaseModel):
    incident_id: str
    modifications: str


class ChatRequest(BaseModel):
    incident_id: str
    message: str


# ==========================================
# WebSocket Endpoint
# ==========================================

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time updates"""
    await manager.connect(websocket)
    
    try:
        # Send initial state
        init_data = {
            "type": "init",
            "payload": {
                "agents": orchestrator.get_agent_states(),
                "incidents": [i.model_dump() for i in orchestrator.get_all_incidents()],
                "stats": orchestrator.get_stats()
            }
        }
        await websocket.send_text(json.dumps(init_data, default=str))
        
        # Keep connection alive and handle incoming messages
        while True:
            try:
                data = await websocket.receive_text()
                message = json.loads(data)
                await handle_websocket_message(websocket, message)
            except WebSocketDisconnect:
                break
            except json.JSONDecodeError:
                await websocket.send_text(json.dumps({
                    "type": "error",
                    "payload": {"message": "Invalid JSON"}
                }, default=str))
                
    except Exception as e:
        print(f"[WebSocket] Error: {e}")
    finally:
        await manager.disconnect(websocket)


async def handle_websocket_message(websocket: WebSocket, message: dict):
    """Handle incoming WebSocket messages"""
    msg_type = message.get("type")
    payload = message.get("payload", {})
    
    if msg_type == "approve":
        incident_id = payload.get("incident_id")
        if incident_id:
            await orchestrator.approve_incident(incident_id)
    
    elif msg_type == "reject":
        incident_id = payload.get("incident_id")
        reason = payload.get("reason", "")
        if incident_id:
            await orchestrator.reject_incident(incident_id, reason)
    
    elif msg_type == "modify":
        incident_id = payload.get("incident_id")
        modifications = payload.get("modifications", "")
        if incident_id and modifications:
            await orchestrator.modify_incident(incident_id, modifications)
    
    elif msg_type == "chat":
        incident_id = payload.get("incident_id")
        message_text = payload.get("message", "")
        if incident_id and message_text:
            await orchestrator.chat(incident_id, message_text)
    
    elif msg_type == "get_incident":
        incident_id = payload.get("incident_id")
        if incident_id:
            incident = orchestrator.get_incident(incident_id)
            trace = orchestrator.get_trace(incident_id)
            await websocket.send_text(json.dumps({
                "type": "incident_details",
                "payload": {
                    "incident": incident.model_dump() if incident else None,
                    "trace": trace.model_dump() if trace else None,
                    "chat_history": orchestrator.get_chat_history(incident_id)
                }
            }, default=str))
    
    elif msg_type == "get_agents":
        await websocket.send_text(json.dumps({
            "type": "agent_states",
            "payload": orchestrator.get_agent_states()
        }, default=str))
    
    elif msg_type == "get_stats":
        await websocket.send_text(json.dumps({
            "type": "stats",
            "payload": orchestrator.get_stats()
        }, default=str))


# ==========================================
# REST API Endpoints
# ==========================================

@app.get("/")
async def root():
    """Health check"""
    return {
        "status": "running",
        "name": "SENTINEL-AI",
        "version": "1.0.0"
    }


@app.get("/api/agents")
async def get_agents():
    """Get all agent states"""
    return orchestrator.get_agent_states()


@app.get("/api/incidents")
async def get_incidents():
    """Get all incidents"""
    return [i.model_dump() for i in orchestrator.get_all_incidents()]


@app.get("/api/incidents/{incident_id}")
async def get_incident(incident_id: str):
    """Get a specific incident with trace"""
    incident = orchestrator.get_incident(incident_id)
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    
    trace = orchestrator.get_trace(incident_id)
    chat_history = orchestrator.get_chat_history(incident_id)
    
    return {
        "incident": incident.model_dump(),
        "trace": trace.model_dump() if trace else None,
        "chat_history": chat_history
    }


@app.post("/api/approve")
async def approve_incident(request: ApprovalRequest):
    """Approve an incident"""
    await orchestrator.approve_incident(request.incident_id)
    return {"status": "approved", "incident_id": request.incident_id}


@app.post("/api/reject")
async def reject_incident(request: RejectRequest):
    """Reject an incident"""
    await orchestrator.reject_incident(request.incident_id, request.reason)
    return {"status": "rejected", "incident_id": request.incident_id}


@app.post("/api/modify")
async def modify_incident(request: ModifyRequest):
    """Modify an incident plan"""
    await orchestrator.modify_incident(request.incident_id, request.modifications)
    return {"status": "modified", "incident_id": request.incident_id}


@app.post("/api/chat")
async def chat(request: ChatRequest):
    """Send a chat message"""
    response = await orchestrator.chat(request.incident_id, request.message)
    return {"response": response}


# ADK Chat Request Model
class ADKChatRequest(BaseModel):
    message: str
    session_id: str = "default"


@app.post("/api/adk-chat")
async def adk_chat(request: ADKChatRequest):
    """
    Chat with the ADK agent.
    Provides conversational AI similar to ADK CLI/Web.
    """
    from services.adk_chat_service import adk_chat_service
    result = await adk_chat_service.chat(request.message, request.session_id)
    return result


@app.delete("/api/adk-chat/{session_id}")
async def clear_adk_chat(session_id: str):
    """Clear chat history for a session"""
    from services.adk_chat_service import adk_chat_service
    adk_chat_service.clear_session(session_id)
    return {"status": "cleared", "session_id": session_id}


@app.get("/api/adk-chat/{session_id}/history")
async def get_adk_chat_history(session_id: str):
    """Get chat history for a session"""
    from services.adk_chat_service import adk_chat_service
    return {"history": adk_chat_service.get_history(session_id)}


@app.get("/api/stats")
async def get_stats():
    """Get system statistics"""
    return orchestrator.get_stats()


# ==========================================
# Main Entry Point
# ==========================================

if __name__ == "__main__":
    import uvicorn
    
    print(f"Starting SENTINEL-AI on port {config.websocket_port}")
    print(f"LLM Mode: {'Mock' if config.use_mock_llm else 'Gemini API'}")
    print(f"Execution Mode: {config.execution_mode}")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=config.websocket_port,
        reload=False
    )
