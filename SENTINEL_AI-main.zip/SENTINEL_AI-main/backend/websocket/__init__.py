"""
SENTINEL-AI WebSocket Manager
Handles real-time communication with frontend clients.
"""
import json
import asyncio
from typing import Set, Dict, Any
from fastapi import WebSocket
from datetime import datetime


class ConnectionManager:
    """Manages WebSocket connections and broadcasts messages to all clients"""
    
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()
        self._lock = asyncio.Lock()
    
    async def connect(self, websocket: WebSocket):
        """Accept and register a new WebSocket connection"""
        await websocket.accept()
        async with self._lock:
            self.active_connections.add(websocket)
        print(f"[WebSocket] Client connected. Total: {len(self.active_connections)}")
    
    async def disconnect(self, websocket: WebSocket):
        """Remove a WebSocket connection"""
        async with self._lock:
            self.active_connections.discard(websocket)
        print(f"[WebSocket] Client disconnected. Total: {len(self.active_connections)}")
    
    async def broadcast(self, message_type: str, payload: Dict[str, Any]):
        """Broadcast a message to all connected clients"""
        if not self.active_connections:
            return
        
        message = {
            "type": message_type,
            "payload": payload,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        message_json = json.dumps(message, default=str)
        
        # Send to all connections, handling disconnections gracefully
        disconnected = set()
        async with self._lock:
            for connection in self.active_connections:
                try:
                    await connection.send_text(message_json)
                except Exception as e:
                    print(f"[WebSocket] Error sending to client: {e}")
                    disconnected.add(connection)
            
            # Remove disconnected clients
            self.active_connections -= disconnected
    
    async def send_log(self, log_data: Dict[str, Any]):
        """Broadcast a new log entry"""
        await self.broadcast("log", log_data)
    
    async def send_incident(self, incident_data: Dict[str, Any]):
        """Broadcast a new incident"""
        await self.broadcast("incident", incident_data)
    
    async def send_incident_update(self, incident_data: Dict[str, Any]):
        """Broadcast an incident state update"""
        await self.broadcast("incident_update", incident_data)
    
    async def send_agent_state(self, agent_state: Dict[str, Any]):
        """Broadcast agent state update for observability"""
        await self.broadcast("agent_state", agent_state)
    
    async def send_trace_entry(self, trace_entry: Dict[str, Any]):
        """Broadcast a new decision trace entry"""
        await self.broadcast("trace_entry", trace_entry)
    
    async def send_chat_message(self, chat_data: Dict[str, Any]):
        """Broadcast a chat message"""
        await self.broadcast("chat_message", chat_data)
    
    async def send_notification(self, notification: Dict[str, Any]):
        """Broadcast a notification (alerts, errors, etc.)"""
        await self.broadcast("notification", notification)


# Global connection manager instance
manager = ConnectionManager()
