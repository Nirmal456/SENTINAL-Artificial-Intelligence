"""
SENTINEL-AI Anomaly Detection System
Hybrid approach: Statistical (Z-Score/EWMA) + ML (Isolation Forest)
"""
import numpy as np
from collections import deque
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from sklearn.ensemble import IsolationForest
import asyncio

from models import (
    Log, LogLevel, ServiceMetrics, 
    StatisticalAnomalySignal, MLAnomalySignal, AnomalyDetails
)
from config import config


class MetricAggregator:
    """
    Aggregates raw logs into time-series features using a sliding window.
    Feeds data to the anomaly detectors.
    """
    
    def __init__(self, window_seconds: int = 30):
        self.window_seconds = window_seconds
        # Store logs per service: {service: deque of (timestamp, log)}
        self._logs: Dict[str, deque] = {s: deque() for s in config.services}
        # Store computed metrics per service
        self._metrics: Dict[str, ServiceMetrics] = {}
    
    def add_log(self, log: Log) -> ServiceMetrics:
        """
        Add a new log and compute updated metrics for the service.
        Returns the current metrics for the affected service.
        """
        service = log.service
        now = datetime.utcnow()
        
        # Ensure service queue exists
        if service not in self._logs:
            self._logs[service] = deque()
        
        # Add the new log
        self._logs[service].append((now, log))
        
        # Remove logs outside the window
        cutoff = now - timedelta(seconds=self.window_seconds)
        while self._logs[service] and self._logs[service][0][0] < cutoff:
            self._logs[service].popleft()
        
        # Compute metrics
        return self._compute_metrics(service, now)
    
    def _compute_metrics(self, service: str, now: datetime) -> ServiceMetrics:
        """Compute aggregated metrics for a service"""
        logs_in_window = [log for _, log in self._logs[service]]
        
        if not logs_in_window:
            return ServiceMetrics(
                service=service,
                window_start=now - timedelta(seconds=self.window_seconds),
                window_end=now
            )
        
        total_logs = len(logs_in_window)
        
        # Error rate: (ERROR + CRITICAL) / total
        error_count = sum(1 for log in logs_in_window 
                         if log.level in [LogLevel.ERROR, LogLevel.CRITICAL])
        error_rate = error_count / total_logs if total_logs > 0 else 0.0
        
        # Retry count average
        retry_counts = [log.retry_count for log in logs_in_window]
        retry_count_avg = np.mean(retry_counts) if retry_counts else 0.0
        
        # Latency P95
        latencies = [log.response_time_ms for log in logs_in_window 
                     if log.response_time_ms is not None]
        latency_p95 = np.percentile(latencies, 95) if latencies else 0.0
        
        # Log frequency (logs per second)
        log_frequency = total_logs / self.window_seconds
        
        # Error burst: errors in last 10s vs average rate
        burst_window = 10
        burst_cutoff = now - timedelta(seconds=burst_window)
        recent_errors = sum(1 for ts, log in self._logs[service]
                          if ts >= burst_cutoff and 
                          log.level in [LogLevel.ERROR, LogLevel.CRITICAL])
        expected_errors = (error_rate * burst_window * log_frequency)
        error_burst = recent_errors / max(expected_errors, 0.1)  # Avoid div by zero
        
        metrics = ServiceMetrics(
            service=service,
            window_start=now - timedelta(seconds=self.window_seconds),
            window_end=now,
            error_rate=error_rate,
            retry_count_avg=float(retry_count_avg),
            latency_p95=float(latency_p95),
            log_frequency=log_frequency,
            error_burst=error_burst,
            total_logs=total_logs,
            error_count=error_count
        )
        
        self._metrics[service] = metrics
        return metrics
    
    def get_metrics(self, service: str) -> Optional[ServiceMetrics]:
        """Get current metrics for a service"""
        return self._metrics.get(service)
    
    def get_all_metrics(self) -> Dict[str, ServiceMetrics]:
        """Get metrics for all services"""
        return self._metrics.copy()


class StatisticalDetector:
    """
    Z-Score / EWMA based anomaly detector.
    Primary detector - fast and explainable.
    """
    
    def __init__(self, alpha: float = 0.3, zscore_threshold: float = 2.0):
        self.alpha = alpha  # EWMA smoothing factor
        self.zscore_threshold = zscore_threshold
        
        # Baselines per service per metric: {service: {metric: (ewma, variance)}}
        self._baselines: Dict[str, Dict[str, Tuple[float, float]]] = {}
        
        # Historical values for std dev calculation
        self._history: Dict[str, Dict[str, deque]] = {}
        self._history_size = 50
    
    def detect(self, metrics: ServiceMetrics) -> List[StatisticalAnomalySignal]:
        """
        Detect anomalies in the metrics using Z-Score with EWMA baseline.
        Returns list of anomaly signals (one per anomalous metric).
        """
        service = metrics.service
        signals = []
        
        # Initialize if needed
        if service not in self._baselines:
            self._baselines[service] = {}
            self._history[service] = {}
        
        # Check each metric
        metric_values = {
            "error_rate": metrics.error_rate,
            "retry_count_avg": metrics.retry_count_avg,
            "latency_p95": metrics.latency_p95,
            "error_burst": metrics.error_burst
        }
        
        for metric_name, current_value in metric_values.items():
            signal = self._check_metric(service, metric_name, current_value)
            if signal:
                signals.append(signal)
        
        return signals
    
    def _check_metric(
        self, 
        service: str, 
        metric_name: str, 
        current_value: float
    ) -> Optional[StatisticalAnomalySignal]:
        """Check a single metric for anomaly"""
        
        # Initialize history if needed
        if metric_name not in self._history[service]:
            self._history[service][metric_name] = deque(maxlen=self._history_size)
        
        history = self._history[service][metric_name]
        
        # Need at least some history for baseline
        if len(history) < 5:
            history.append(current_value)
            return None
        
        # Get or compute baseline
        if metric_name not in self._baselines[service]:
            # Initialize baseline with mean of history
            self._baselines[service][metric_name] = (
                float(np.mean(history)),
                float(np.var(history)) + 0.001  # Add small value to avoid zero variance
            )
        
        ewma, variance = self._baselines[service][metric_name]
        std_dev = np.sqrt(variance)
        
        # Compute Z-score
        z_score = (current_value - ewma) / max(std_dev, 0.001)
        
        # Update EWMA
        new_ewma = self.alpha * current_value + (1 - self.alpha) * ewma
        new_variance = self.alpha * (current_value - new_ewma) ** 2 + (1 - self.alpha) * variance
        self._baselines[service][metric_name] = (new_ewma, new_variance)
        
        # Add to history
        history.append(current_value)
        
        # Check threshold
        is_anomaly = abs(z_score) > self.zscore_threshold
        
        if is_anomaly:
            # Create explanation
            direction = "above" if z_score > 0 else "below"
            ratio = current_value / max(ewma, 0.001)
            
            return StatisticalAnomalySignal(
                detector="statistical",
                metric=metric_name,
                current_value=round(current_value, 4),
                baseline=round(ewma, 4),
                z_score=round(z_score, 2),
                threshold=self.zscore_threshold,
                is_anomaly=True,
                explanation=f"{metric_name} is {ratio:.1f}x {direction} normal baseline (z-score: {z_score:.2f})"
            )
        
        return None


class IsolationForestDetector:
    """
    Isolation Forest based anomaly detector.
    Secondary detector - validates multivariate anomalies.
    """
    
    def __init__(self, contamination: float = 0.05, warmup_samples: int = 30):
        self.contamination = contamination
        self.warmup_samples = warmup_samples
        
        # Model per service
        self._models: Dict[str, IsolationForest] = {}
        
        # Training data per service
        self._training_data: Dict[str, List[List[float]]] = {}
        
        # Is model ready?
        self._is_trained: Dict[str, bool] = {}
    
    def detect(self, metrics: ServiceMetrics) -> Optional[MLAnomalySignal]:
        """
        Detect multivariate anomalies using Isolation Forest.
        Returns None if model not ready or no anomaly detected.
        """
        service = metrics.service
        
        # Feature vector
        features = [
            metrics.error_rate,
            metrics.retry_count_avg,
            metrics.latency_p95,
            metrics.log_frequency,
            metrics.error_burst
        ]
        
        # Initialize if needed
        if service not in self._training_data:
            self._training_data[service] = []
            self._is_trained[service] = False
        
        # Add to training data
        self._training_data[service].append(features)
        
        # Check if we have enough data to train
        if len(self._training_data[service]) < self.warmup_samples:
            return None
        
        # Train model if not trained
        if not self._is_trained[service]:
            self._train_model(service)
        
        # Predict
        try:
            model = self._models[service]
            feature_array = np.array(features).reshape(1, -1)
            
            # Get anomaly score (-1 for anomaly, 1 for normal)
            prediction = model.predict(feature_array)[0]
            score = model.score_samples(feature_array)[0]
            
            is_anomaly = prediction == -1
            
            if is_anomaly:
                # Compute feature contributions (approximate)
                contributions = self._compute_contributions(service, features)
                
                return MLAnomalySignal(
                    detector="isolation_forest",
                    anomaly_score=round(float(score), 4),
                    is_anomaly=True,
                    feature_contributions=contributions,
                    explanation=self._generate_explanation(contributions)
                )
            
            return None
            
        except Exception as e:
            print(f"[IsolationForest] Error detecting for {service}: {e}")
            return None
    
    def _train_model(self, service: str):
        """Train the Isolation Forest model for a service"""
        try:
            data = np.array(self._training_data[service])
            model = IsolationForest(
                contamination=self.contamination,
                random_state=42,
                n_estimators=100
            )
            model.fit(data)
            self._models[service] = model
            self._is_trained[service] = True
            print(f"[IsolationForest] Model trained for {service} with {len(data)} samples")
        except Exception as e:
            print(f"[IsolationForest] Training failed for {service}: {e}")
    
    def _compute_contributions(
        self, 
        service: str, 
        features: List[float]
    ) -> Dict[str, float]:
        """
        Approximate feature contributions to the anomaly.
        Using deviation from mean as a proxy.
        """
        feature_names = ["error_rate", "retry_count_avg", "latency_p95", 
                         "log_frequency", "error_burst"]
        
        data = np.array(self._training_data[service])
        means = data.mean(axis=0)
        stds = data.std(axis=0) + 0.001
        
        # Normalized deviations
        deviations = np.abs((np.array(features) - means) / stds)
        total = deviations.sum()
        
        contributions = {}
        for i, name in enumerate(feature_names):
            contributions[name] = round(float(deviations[i] / total), 2) if total > 0 else 0.0
        
        return contributions
    
    def _generate_explanation(self, contributions: Dict[str, float]) -> str:
        """Generate human-readable explanation"""
        # Sort by contribution
        sorted_features = sorted(contributions.items(), key=lambda x: x[1], reverse=True)
        top_features = [f[0] for f in sorted_features[:2]]
        
        return f"Multivariate anomaly detected: high {' + '.join(top_features)}"


class TimeSeriesAnomalyDetector:
    """
    Combined hybrid anomaly detector.
    Uses both statistical and ML methods, combines signals.
    """
    
    def __init__(self):
        self.metric_aggregator = MetricAggregator(window_seconds=config.sliding_window_seconds)
        self.statistical_detector = StatisticalDetector(
            zscore_threshold=config.zscore_threshold
        )
        self.isolation_forest = IsolationForestDetector(
            contamination=config.isolation_forest_contamination
        )
        
        self.statistical_weight = config.statistical_weight
        self.ml_weight = config.ml_weight
    
    async def process_log(self, log: Log) -> Optional[AnomalyDetails]:
        """
        Process a new log and detect anomalies.
        Returns AnomalyDetails if anomaly detected, None otherwise.
        """
        # Aggregate metrics
        metrics = self.metric_aggregator.add_log(log)
        
        # Run statistical detection
        stat_signals = self.statistical_detector.detect(metrics)
        
        # Run ML detection (may return None if warming up)
        ml_signal = self.isolation_forest.detect(metrics)
        
        # Combine signals
        return self._combine_signals(stat_signals, ml_signal)
    
    def _combine_signals(
        self,
        stat_signals: List[StatisticalAnomalySignal],
        ml_signal: Optional[MLAnomalySignal]
    ) -> Optional[AnomalyDetails]:
        """
        Combine statistical and ML signals into final anomaly decision.
        """
        has_stat_anomaly = len(stat_signals) > 0
        has_ml_anomaly = ml_signal is not None
        
        if not has_stat_anomaly and not has_ml_anomaly:
            return None
        
        # Compute combined confidence
        stat_score = 1.0 if has_stat_anomaly else 0.0
        ml_score = 1.0 if has_ml_anomaly else 0.0
        
        combined_confidence = (
            self.statistical_weight * stat_score + 
            self.ml_weight * ml_score
        )
        
        # Only create anomaly if confidence threshold met
        if combined_confidence < 0.5:
            return None
        
        # Use the strongest statistical signal
        primary_stat = stat_signals[0] if stat_signals else None
        
        return AnomalyDetails(
            statistical_signal=primary_stat,
            ml_signal=ml_signal,
            combined_confidence=round(combined_confidence, 2)
        )


# Global detector instance
anomaly_detector = TimeSeriesAnomalyDetector()
