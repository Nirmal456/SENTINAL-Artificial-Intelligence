"""
SENTINEL-AI ADK Chat Service
Provides API for chatting with the ADK agent from the React dashboard.
"""
import os
from typing import Optional
from dotenv import load_dotenv

load_dotenv()

# Try to import google.genai for direct Gemini access
try:
    from google import genai
    from google.genai import types
    GENAI_AVAILABLE = True
except ImportError:
    GENAI_AVAILABLE = False
    print("[ADKChatService] google-genai not available")


class ADKChatService:
    """
    Provides chat functionality similar to ADK CLI/Web.
    Uses Google Gemini directly for conversational AI.
    """
    
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY", "")
        self.use_mock = os.getenv("USE_MOCK_LLM", "false").lower() == "true"
        self.client = None
        self.chat_sessions = {}  # session_id -> chat history
        
        if self.use_mock:
            print("[ADKChatService] Using MOCK mode (no API calls)")
        elif GENAI_AVAILABLE and self.api_key:
            try:
                self.client = genai.Client(api_key=self.api_key)
                print("[ADKChatService] Initialized with Gemini API")
            except Exception as e:
                print(f"[ADKChatService] Failed to initialize: {e}")
        
        # System prompt for the agent
        self.system_prompt = """You are SENTINEL-AI, an autonomous incident management assistant.

You help SRE engineers and operators understand and manage production incidents. You have access to these tools:

1. **analyze_incident** - Analyze an incident and provide root cause analysis
2. **classify_risk** - Classify the risk level of an incident
3. **get_incident_history** - Get historical incidents for a service
4. **execute_remediation** - Execute remediation steps (requires approval for HIGH/CRITICAL)

When answering questions:
- Be concise and technical
- Provide actionable insights
- Explain your reasoning
- If asked about specific services, use the relevant tools
- For HIGH/CRITICAL incidents, always emphasize the need for human approval

You are monitoring these services: auth-service, api-server, payment-service, worker-service, db

Example questions you can answer:
- "What happened to the payment service?"
- "Analyze the last critical incident"
- "What's the incident history for the database?"
- "Should I approve this remediation plan?"
"""
    
    async def chat(self, message: str, session_id: str = "default") -> dict:
        """
        Send a message and get a response from the AI agent.
        """
        # Initialize session if needed
        if session_id not in self.chat_sessions:
            self.chat_sessions[session_id] = []
        
        # Add user message to history
        self.chat_sessions[session_id].append({
            "role": "user",
            "content": message
        })
        
        # Use mock responses if enabled
        if self.use_mock:
            ai_response = self._generate_mock_response(message)
            tool_calls = self._detect_tool_usage(message, ai_response)
            
            self.chat_sessions[session_id].append({
                "role": "assistant",
                "content": ai_response
            })
            
            return {
                "response": ai_response,
                "tool_calls": tool_calls,
                "session_id": session_id
            }
        
        if not self.client:
            return {
                "response": "ADK Chat is not configured. Please set GEMINI_API_KEY in .env or enable USE_MOCK_LLM=true",
                "tool_calls": [],
                "session_id": session_id
            }
        
        try:
            # Build conversation history
            contents = []
            
            # Add system prompt
            contents.append(types.Content(
                role="user",
                parts=[types.Part(text=f"System context: {self.system_prompt}")]
            ))
            contents.append(types.Content(
                role="model",
                parts=[types.Part(text="I understand. I'm SENTINEL-AI, ready to help with incident management.")]
            ))
            
            # Add conversation history
            for msg in self.chat_sessions[session_id][-10:]:  # Last 10 messages
                contents.append(types.Content(
                    role="user" if msg["role"] == "user" else "model",
                    parts=[types.Part(text=msg["content"])]
                ))
            
            # Generate response
            response = self.client.models.generate_content(
                model="gemini-2.0-flash-lite",
                contents=contents,
                config=types.GenerateContentConfig(
                    temperature=0.7,
                    max_output_tokens=1000
                )
            )
            
            ai_response = response.text
            
            # Add AI response to history
            self.chat_sessions[session_id].append({
                "role": "assistant",
                "content": ai_response
            })
            
            # Simulate tool detection (for demo purposes)
            tool_calls = self._detect_tool_usage(message, ai_response)
            
            return {
                "response": ai_response,
                "tool_calls": tool_calls,
                "session_id": session_id
            }
            
        except Exception as e:
            error_msg = f"Error generating response: {str(e)}"
            print(f"[ADKChatService] {error_msg}")
            return {
                "response": error_msg,
                "tool_calls": [],
                "session_id": session_id
            }
    
    def _generate_mock_response(self, message: str) -> str:
        """Generate mock responses based on keywords in the message."""
        message_lower = message.lower()
        
        if any(word in message_lower for word in ["status", "what happened", "payment", "service"]):
            return """Based on recent monitoring data, the payment service is experiencing elevated error rates (12% above baseline). 

**Current Status:**
- Service: payment-service
- Health: DEGRADED
- Error Rate: 24.5 errors/min
- Response Time: 850ms (normal: 200ms)

**Likely Cause:**
- Database connection pool exhaustion
- Possible memory leak in payment processor

**Recommendation:**
I suggest analyzing the incident in detail. Would you like me to run a full diagnostic?"""
        
        elif any(word in message_lower for word in ["analyze", "critical", "incident"]):
            return """I've analyzed the most recent CRITICAL incident:

**Incident ID:** fa6d01e3
**Service:** auth-service  
**Severity:** CRITICAL
**Duration:** 8 minutes

**Root Cause Analysis:**
The authentication service experienced a cascading failure due to:
1. Redis cache cluster failover (primary node crashed)
2. All auth requests hit the database directly
3. Database connection pool saturated (200/200 connections)
4. Request timeouts triggered circuit breakers

**Remediation Plan:**
1. Scale Redis cluster to 3 nodes (currently 2)
2. Increase DB connection pool to 500
3. Add request rate limiting (1000 req/s per client)

**Risk Level:** HIGH - Requires human approval before execution.

Would you like me to proceed with remediation after your approval?"""
        
        elif any(word in message_lower for word in ["history", "past", "previous"]):
            return """**Incident History for Last 7 Days:**

| Date | Service | Severity | Root Cause | Resolution |
|------|---------|----------|------------|------------|
| Today | auth-service | CRITICAL | Redis failover | Manual (8min) |
| Yesterday | payment-service | HIGH | DB connection pool | Auto (3min) |
| 2 days ago | api-server | MEDIUM | Memory leak | Auto (5min) |
| 4 days ago | worker-service | LOW | Queue backlog | Auto (2min) |

**Patterns Detected:**
- 60% of incidents are database-related
- Peak incident time: 9-11 AM UTC
- Average resolution time: 4.5 minutes

**Recommendations:**
- Increase database connection pools across all services
- Add memory profiling to detect leaks earlier
- Consider implementing read replicas for high-traffic services"""
        
        elif any(word in message_lower for word in ["approve", "remediation", "execute"]):
            return """**Remediation Approval Required**

Before executing any remediation for HIGH or CRITICAL incidents, I need explicit human approval due to SENTINEL-AI's safety guardrails.

**Current Pending Approvals:**
- Incident fa6d01e3 (auth-service) - Awaiting your decision

**Approval Options:**
1. ✅ **Approve** - Execute the proposed remediation plan
2. ❌ **Reject** - Cancel remediation, manual intervention required
3. ✏️ **Modify** - Adjust the plan before execution

Please review the remediation plan in the dashboard and make your decision."""
        
        else:
            return """I'm SENTINEL-AI, your autonomous incident management assistant.

I can help you with:
- **Analyzing incidents** - Root cause analysis and diagnostics
- **Classifying risk** - Determine severity and approval requirements  
- **Incident history** - Learn from past incidents
- **Execute remediation** - Auto-fix LOW/MEDIUM, human approval for HIGH/CRITICAL

Currently monitoring: auth-service, api-server, payment-service, worker-service, db

What would you like to know about your production systems?"""
    
    def _detect_tool_usage(self, message: str, response: str) -> list:
        """
        Detect which tools the agent is conceptually using.
        (For display purposes in the UI)
        """
        tools = []
        message_lower = message.lower()
        response_lower = response.lower()
        
        if any(word in message_lower for word in ["analyze", "diagnose", "root cause", "why"]):
            tools.append({"name": "analyze_incident", "status": "completed"})
        
        if any(word in message_lower for word in ["risk", "severity", "classify", "critical", "high"]):
            tools.append({"name": "classify_risk", "status": "completed"})
        
        if any(word in message_lower for word in ["history", "past", "previous", "last"]):
            tools.append({"name": "get_incident_history", "status": "completed"})
        
        if any(word in message_lower for word in ["fix", "remediate", "execute", "resolve"]):
            tools.append({"name": "execute_remediation", "status": "pending_approval"})
        
        return tools
    
    def clear_session(self, session_id: str = "default"):
        """Clear chat history for a session"""
        if session_id in self.chat_sessions:
            self.chat_sessions[session_id] = []
    
    def get_history(self, session_id: str = "default") -> list:
        """Get chat history for a session"""
        return self.chat_sessions.get(session_id, [])


# Global instance
adk_chat_service = ADKChatService()
