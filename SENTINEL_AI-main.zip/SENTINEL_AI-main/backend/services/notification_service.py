"""
SENTINEL-AI Notification Service
Sends WhatsApp and Email alerts for CRITICAL incidents.
Uses Twilio Sandbox for WhatsApp (free for testing).
"""
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional
from datetime import datetime

try:
    from twilio.rest import Client as TwilioClient
    TWILIO_AVAILABLE = True
except ImportError:
    TWILIO_AVAILABLE = False
    print("[NotificationService] Twilio not installed. Run: pip install twilio")


class NotificationService:
    """
    Handles WhatsApp and Email notifications for critical incidents.
    """
    
    def __init__(self):
        # Twilio WhatsApp Sandbox Config
        self.twilio_sid = os.getenv("TWILIO_ACCOUNT_SID", "")
        self.twilio_token = os.getenv("TWILIO_AUTH_TOKEN", "")
        self.twilio_from = os.getenv("TWILIO_WHATSAPP_FROM", "whatsapp:+14155238886")  # Sandbox number
        self.whatsapp_to = os.getenv("ALERT_WHATSAPP_TO", "")
        
        # Email SMTP Config
        self.smtp_host = os.getenv("SMTP_HOST", "smtp.gmail.com")
        self.smtp_port = int(os.getenv("SMTP_PORT", "587"))
        self.smtp_user = os.getenv("SMTP_USER", "")
        self.smtp_password = os.getenv("SMTP_PASSWORD", "")
        self.email_to = os.getenv("ALERT_EMAIL_TO", "")
        
        # Initialize Twilio client if available
        self.twilio_client = None
        if TWILIO_AVAILABLE and self.twilio_sid and self.twilio_token:
            try:
                self.twilio_client = TwilioClient(self.twilio_sid, self.twilio_token)
                print("[NotificationService] Twilio WhatsApp initialized")
            except Exception as e:
                print(f"[NotificationService] Twilio init failed: {e}")
        
        # Check email config
        self.email_enabled = bool(self.smtp_user and self.smtp_password)
        if self.email_enabled:
            print("[NotificationService] Email alerts initialized")
    
    async def send_whatsapp(self, message: str) -> bool:
        """
        Send WhatsApp message via Twilio Sandbox.
        
        To use Twilio Sandbox:
        1. Go to https://www.twilio.com/console/sms/whatsapp/sandbox
        2. Send "join <your-sandbox-code>" to +1 415 523 8886
        3. Set ALERT_WHATSAPP_TO to your number (whatsapp:+91XXXXXXXXXX)
        """
        if not self.twilio_client or not self.whatsapp_to:
            print("[NotificationService] WhatsApp not configured, skipping")
            return False
        
        try:
            msg = self.twilio_client.messages.create(
                body=message,
                from_=self.twilio_from,
                to=self.whatsapp_to
            )
            print(f"[NotificationService] WhatsApp sent: {msg.sid}")
            return True
        except Exception as e:
            print(f"[NotificationService] WhatsApp failed: {e}")
            return False
    
    async def send_email(self, subject: str, body: str) -> bool:
        """
        Send email via SMTP (Gmail supported).
        
        For Gmail:
        1. Enable 2FA on your Google account
        2. Create App Password: https://myaccount.google.com/apppasswords
        3. Set SMTP_USER and SMTP_PASSWORD in .env
        """
        if not self.email_enabled or not self.email_to:
            print("[NotificationService] Email not configured, skipping")
            return False
        
        try:
            msg = MIMEMultipart()
            msg['From'] = self.smtp_user
            msg['To'] = self.email_to
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'html'))
            
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_user, self.smtp_password)
                server.send_message(msg)
            
            print(f"[NotificationService] Email sent to {self.email_to}")
            return True
        except Exception as e:
            print(f"[NotificationService] Email failed: {e}")
            return False
    
    async def notify_critical_incident(self, incident: dict) -> dict:
        """
        Send both WhatsApp and Email alerts for a critical incident.
        Called by ApprovalAgent when HIGH/CRITICAL incidents need approval.
        """
        incident_id = incident.get('incident_id', 'unknown')[:8]
        service = incident.get('affected_service', 'unknown')
        severity = incident.get('severity', 'CRITICAL')
        symptoms = incident.get('symptoms', [])
        root_cause = incident.get('root_cause', 'Analysis pending...')
        
        timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        
        # WhatsApp Message (concise)
        whatsapp_msg = f"""🚨 *SENTINEL-AI ALERT*

*Severity:* {severity}
*Service:* {service}
*Incident ID:* {incident_id}
*Time:* {timestamp}

*Symptoms:*
{chr(10).join(['• ' + s for s in symptoms[:3]])}

*Action Required:* Open dashboard to approve/reject remediation.

http://localhost:5173"""

        # Email Body (detailed HTML)
        email_body = f"""
<html>
<body style="font-family: Arial, sans-serif; background: #1a1a2e; color: white; padding: 20px;">
    <div style="max-width: 600px; margin: 0 auto; background: #16213e; border-radius: 10px; padding: 20px;">
        <h1 style="color: #ff6b6b;">🚨 SENTINEL-AI: {severity} Incident</h1>
        
        <table style="width: 100%; color: white;">
            <tr><td><strong>Incident ID:</strong></td><td>{incident_id}</td></tr>
            <tr><td><strong>Service:</strong></td><td>{service}</td></tr>
            <tr><td><strong>Severity:</strong></td><td style="color: {'#ff6b6b' if severity == 'CRITICAL' else '#ffd93d'};">{severity}</td></tr>
            <tr><td><strong>Detected At:</strong></td><td>{timestamp}</td></tr>
        </table>
        
        <h3 style="color: #00d4ff;">Symptoms</h3>
        <ul>
            {''.join([f'<li>{s}</li>' for s in symptoms])}
        </ul>
        
        <h3 style="color: #00d4ff;">AI Analysis</h3>
        <p style="background: #0f3460; padding: 10px; border-radius: 5px;">
            {root_cause or 'Pending analysis...'}
        </p>
        
        <div style="text-align: center; margin-top: 20px;">
            <a href="http://localhost:5173" style="background: #00d4ff; color: #1a1a2e; padding: 10px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">
                Open Dashboard
            </a>
        </div>
        
        <p style="color: #666; font-size: 12px; margin-top: 30px; text-align: center;">
            SENTINEL-AI Autonomous Incident Management System
        </p>
    </div>
</body>
</html>
"""
        
        # Send both notifications
        results = {
            "whatsapp_sent": False,
            "email_sent": False
        }
        
        results["whatsapp_sent"] = await self.send_whatsapp(whatsapp_msg)
        results["email_sent"] = await self.send_email(
            f"🚨 SENTINEL-AI: {severity} Incident in {service}",
            email_body
        )
        
        return results


# Global instance
notification_service = NotificationService()
