"""
SENTINEL-AI LLM Service
Gemini API integration with Mock LLM fallback.
"""
import os
import json
import asyncio
from typing import Dict, Any, Optional, List
from datetime import datetime

from config import config


class MockLLM:
    """Mock LLM for testing without API calls"""
    
    async def generate(self, prompt: str, incident_data: Dict) -> Dict[str, Any]:
        """Generate mock diagnosis and remediation plan"""
        await asyncio.sleep(1)  # Simulate API latency
        
        service = incident_data.get("affected_service", "unknown-service")
        severity = incident_data.get("severity", "MEDIUM")
        symptoms = incident_data.get("symptoms", [])
        
        # Generate contextual mock response
        root_causes = {
            "auth-service": "Authentication service experiencing high load due to login surge",
            "api-server": "API server memory pressure causing request timeouts",
            "payment-service": "Payment gateway connectivity issues causing transaction failures",
            "worker-service": "Background job queue backlog due to slow consumer",
            "db": "Database connection pool exhaustion from query spike"
        }
        
        remediation_plans = {
            "auth-service": [
                {"step": 1, "action": "Scale auth-service replicas from 3 to 5", "risk": "LOW"},
                {"step": 2, "action": "Clear authentication cache", "risk": "LOW"},
                {"step": 3, "action": "Enable rate limiting for login endpoints", "risk": "MEDIUM"}
            ],
            "api-server": [
                {"step": 1, "action": "Restart unhealthy API server pods", "risk": "LOW"},
                {"step": 2, "action": "Increase memory limits for API pods", "risk": "MEDIUM"},
                {"step": 3, "action": "Enable request queue overflow protection", "risk": "LOW"}
            ],
            "payment-service": [
                {"step": 1, "action": "Reset payment gateway connection pool", "risk": "LOW"},
                {"step": 2, "action": "Retry failed payment webhooks", "risk": "LOW"},
                {"step": 3, "action": "Enable fallback payment processor", "risk": "HIGH"}
            ],
            "worker-service": [
                {"step": 1, "action": "Scale worker pods from 5 to 10", "risk": "LOW"},
                {"step": 2, "action": "Increase job processing concurrency", "risk": "MEDIUM"},
                {"step": 3, "action": "Clear dead letter queue", "risk": "LOW"}
            ],
            "db": [
                {"step": 1, "action": "Kill long-running queries (>30s)", "risk": "MEDIUM"},
                {"step": 2, "action": "Increase connection pool size", "risk": "LOW"},
                {"step": 3, "action": "Enable query result caching", "risk": "LOW"}
            ]
        }
        
        return {
            "root_cause": root_causes.get(service, f"Service {service} experiencing anomalous behavior"),
            "confidence": 0.85,
            "evidence": symptoms[:3] if symptoms else ["Anomaly detected in metrics"],
            "remediation_plan": remediation_plans.get(service, remediation_plans["api-server"]),
            "explanation": f"Based on the detected anomalies in {service}, the root cause appears to be {root_causes.get(service, 'service degradation').lower()}. The recommended remediation plan addresses the immediate issue while minimizing service disruption.",
            "warnings": [
                f"Monitor {service} closely after remediation",
                "Consider reviewing capacity planning after resolution"
            ] if severity in ["HIGH", "CRITICAL"] else []
        }


class GeminiLLM:
    """Gemini API integration for root cause analysis"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self._model = None
        self._initialized = False
    
    async def _initialize(self):
        """Initialize Gemini model"""
        if self._initialized:
            return
        
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            self._model = genai.GenerativeModel('gemini-2.0-flash-lite')
            self._initialized = True
            print("[GeminiLLM] Initialized successfully")
        except Exception as e:
            print(f"[GeminiLLM] Initialization failed: {e}")
            raise
    
    async def generate(self, prompt: str, incident_data: Dict) -> Dict[str, Any]:
        """Generate diagnosis and remediation plan using Gemini"""
        await self._initialize()
        
        # Build context-rich prompt
        full_prompt = f"""You are an expert SRE AI assistant analyzing a production incident.

INCIDENT DETAILS:
- Service: {incident_data.get('affected_service', 'unknown')}
- Severity: {incident_data.get('severity', 'MEDIUM')}
- Symptoms: {json.dumps(incident_data.get('symptoms', []))}
- Confidence Score: {incident_data.get('confidence_score', 0.5)}
- Anomaly Details: {json.dumps(incident_data.get('anomaly_details', {}), default=str)}

TASK:
Analyze this incident and provide:
1. Root cause analysis
2. Step-by-step remediation plan
3. Explanation in plain English
4. Any warnings or considerations

IMPORTANT RULES:
- Do NOT claim certainty without evidence
- Provide clear, actionable steps
- Consider service dependencies
- Prioritize safe, reversible actions

Respond in this exact JSON format:
{{
    "root_cause": "Plain English explanation of the likely root cause",
    "confidence": 0.0-1.0,
    "evidence": ["list of supporting evidence"],
    "remediation_plan": [
        {{"step": 1, "action": "Description of action", "risk": "LOW|MEDIUM|HIGH"}}
    ],
    "explanation": "Human-readable summary for operators",
    "warnings": ["list of warnings or considerations"]
}}

{prompt}"""

        try:
            response = await asyncio.to_thread(
                self._model.generate_content,
                full_prompt
            )
            
            # Parse response
            text = response.text
            
            # Try to extract JSON from response
            if "```json" in text:
                text = text.split("```json")[1].split("```")[0]
            elif "```" in text:
                text = text.split("```")[1].split("```")[0]
            
            result = json.loads(text.strip())
            return result
            
        except json.JSONDecodeError as e:
            print(f"[GeminiLLM] JSON parse error: {e}")
            # Fallback to mock
            mock = MockLLM()
            return await mock.generate(prompt, incident_data)
            
        except Exception as e:
            print(f"[GeminiLLM] Error: {e}")
            # Fallback to mock
            mock = MockLLM()
            return await mock.generate(prompt, incident_data)


class LLMService:
    """
    LLM service that handles Gemini API with mock fallback.
    Used by PlannerAgent and ChatAgent.
    """
    
    def __init__(self):
        self._llm = None
        self._use_mock = config.use_mock_llm or not config.gemini_api_key
    
    def _get_llm(self):
        """Get or create LLM instance"""
        if self._llm is None:
            if self._use_mock:
                print("[LLMService] Using Mock LLM")
                self._llm = MockLLM()
            else:
                print("[LLMService] Using Gemini API")
                self._llm = GeminiLLM(config.gemini_api_key)
        return self._llm
    
    async def analyze_incident(self, incident_data: Dict) -> Dict[str, Any]:
        """Analyze an incident and generate diagnosis + remediation plan"""
        llm = self._get_llm()
        return await llm.generate("Analyze this incident.", incident_data)
    
    async def revalidate_plan(
        self, 
        incident_data: Dict, 
        original_plan: List[Dict],
        modifications: str
    ) -> Dict[str, Any]:
        """Revalidate a modified plan"""
        llm = self._get_llm()
        
        prompt = f"""The human operator has requested modifications to the remediation plan.

ORIGINAL PLAN:
{json.dumps(original_plan, indent=2)}

HUMAN MODIFICATIONS:
{modifications}

Please provide an updated analysis and remediation plan that incorporates the human's feedback while maintaining safety."""

        return await llm.generate(prompt, incident_data)
    
    async def chat(
        self, 
        incident_data: Dict,
        chat_history: List[Dict],
        user_message: str
    ) -> str:
        """Handle chat interaction about an incident"""
        llm = self._get_llm()
        
        # Format chat history
        history_text = "\n".join([
            f"{'Human' if msg['role'] == 'user' else 'AI'}: {msg['content']}"
            for msg in chat_history[-5:]  # Last 5 messages
        ])
        
        prompt = f"""This is a conversation about an incident.

CHAT HISTORY:
{history_text}

HUMAN'S NEW MESSAGE:
{user_message}

Respond helpfully and concisely about the incident and remediation options."""

        result = await llm.generate(prompt, incident_data)
        
        # For chat, return just the explanation
        return result.get("explanation", "I can help you understand the incident and remediation options. What would you like to know?")


# Global LLM service instance
llm_service = LLMService()
