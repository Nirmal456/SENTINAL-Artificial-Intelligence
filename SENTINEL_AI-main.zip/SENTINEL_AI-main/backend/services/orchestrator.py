"""
SENTINEL-AI Orchestrator
Coordinates all agents and manages incident workflows.
"""
import asyncio
from typing import Dict

from agents.log_watcher import log_watcher, LogWatcherAgent
from agents.incident_detector import incident_detector, IncidentDetectorAgent
from agents.risk_classifier import risk_classifier, RiskClassifierAgent
from agents.executor import executor, ExecutorAgent
from agents.planner import planner, PlannerAgent
from agents.approval import approval_agent, ApprovalAgent
from agents.chat import chat_agent, ChatAgent
from agents.memory import memory_agent, MemoryAgent
from models import Incident, DecisionTrace


class Orchestrator:
    """
    Central orchestrator that coordinates all agents.
    Manages incident lifecycle and agent communication.
    """
    
    def __init__(self):
        # Agents
        self.log_watcher = log_watcher
        self.incident_detector = incident_detector
        self.risk_classifier = risk_classifier
        self.executor = executor
        self.planner = planner
        self.approval_agent = approval_agent
        self.chat_agent = chat_agent
        self.memory_agent = memory_agent
        
        # Shared traces
        self._traces: Dict[str, DecisionTrace] = {}
        
        # Wire up agents
        self._setup_agent_connections()
    
    def _setup_agent_connections(self):
        """Wire up agent callbacks and dependencies"""
        
        # Share traces with all agents
        self.risk_classifier.set_traces(self._traces)
        self.executor.set_traces(self._traces)
        self.planner.set_traces(self._traces)
        self.approval_agent.set_traces(self._traces)
        self.chat_agent.set_traces(self._traces)
        
        # LogWatcherAgent -> IncidentDetectorAgent
        self.log_watcher.set_log_callback(self._on_log)
        
        # IncidentDetectorAgent -> RiskClassifierAgent
        self.incident_detector.set_incident_callback(self._on_incident_detected)
        
        # RiskClassifierAgent -> ExecutorAgent (auto) or PlannerAgent (human)
        self.risk_classifier.set_auto_execute_callback(self._on_auto_execute)
        self.risk_classifier.set_human_required_callback(self._on_human_required)
        
        # ApprovalAgent -> ExecutorAgent (approved) or end (rejected)
        self.approval_agent.set_approved_callback(self._on_approved)
        self.approval_agent.set_rejected_callback(self._on_rejected)
        self.approval_agent.set_modified_callback(self._on_modified)
    
    async def start(self):
        """Start all agents"""
        print("[Orchestrator] Starting all agents...")
        
        await self.memory_agent.start()
        await self.executor.start()
        await self.planner.start()
        await self.approval_agent.start()
        await self.chat_agent.start()
        await self.risk_classifier.start()
        await self.incident_detector.start()
        await self.log_watcher.start()
        
        print("[Orchestrator] All agents started")
    
    async def stop(self):
        """Stop all agents"""
        print("[Orchestrator] Stopping all agents...")
        
        await self.log_watcher.stop()
        await self.incident_detector.stop()
        await self.risk_classifier.stop()
        await self.approval_agent.stop()
        await self.chat_agent.stop()
        await self.planner.stop()
        await self.executor.stop()
        await self.memory_agent.stop()
        
        print("[Orchestrator] All agents stopped")
    
    # ==========================================
    # Workflow Callbacks
    # ==========================================
    
    async def _on_log(self, log):
        """Handle new log from LogWatcherAgent"""
        await self.incident_detector.process_log(log)
    
    async def _on_incident_detected(self, incident: Incident, trace: DecisionTrace):
        """Handle new incident from IncidentDetectorAgent"""
        self._traces[incident.incident_id] = trace
        await self.risk_classifier.classify(incident, trace)
    
    async def _on_auto_execute(self, incident: Incident, trace: DecisionTrace):
        """Handle auto-execute path for LOW/MEDIUM incidents"""
        print(f"[Orchestrator] Auto-executing for {incident.incident_id[:8]}")
        
        # Execute immediately
        success = await self.executor.execute(incident, trace)
        
        # Store in memory
        await self.memory_agent.store_incident(incident, trace)
    
    async def _on_human_required(self, incident: Incident, trace: DecisionTrace):
        """Handle human-required path for HIGH/CRITICAL incidents"""
        print(f"[Orchestrator] Human required for {incident.incident_id[:8]}")
        
        # Get AI diagnosis first
        await self.planner.analyze(incident, trace)
        
        # Then request human approval
        await self.approval_agent.request_approval(incident, trace)
    
    async def _on_approved(self, incident: Incident, trace: DecisionTrace):
        """Handle approved incident"""
        print(f"[Orchestrator] Incident {incident.incident_id[:8]} approved, executing...")
        
        # Execute the approved plan
        success = await self.executor.execute(incident, trace)
        
        # Store in memory
        await self.memory_agent.store_incident(incident, trace)
    
    async def _on_rejected(self, incident: Incident, trace: DecisionTrace):
        """Handle rejected incident"""
        print(f"[Orchestrator] Incident {incident.incident_id[:8]} rejected")
        
        # Store in memory
        await self.memory_agent.store_incident(incident, trace)
    
    async def _on_modified(self, incident: Incident, trace: DecisionTrace, modifications: str):
        """Handle modified plan - needs revalidation"""
        print(f"[Orchestrator] Incident {incident.incident_id[:8]} modified, revalidating...")
        
        # Revalidate with LLM
        await self.planner.revalidate(incident, trace, modifications)
        
        # Re-request approval with updated plan
        await self.approval_agent.request_approval(incident, trace)
    
    # ==========================================
    # Public API Methods
    # ==========================================
    
    async def approve_incident(self, incident_id: str):
        """API: Approve an incident"""
        await self.approval_agent.approve(incident_id)
    
    async def reject_incident(self, incident_id: str, reason: str = ""):
        """API: Reject an incident"""
        await self.approval_agent.reject(incident_id, reason)
    
    async def modify_incident(self, incident_id: str, modifications: str):
        """API: Modify an incident plan"""
        await self.approval_agent.modify(incident_id, modifications)
    
    async def chat(self, incident_id: str, message: str) -> str:
        """API: Send chat message about an incident"""
        incident = self.incident_detector.get_incident(incident_id)
        if incident:
            return await self.chat_agent.chat(incident_id, incident, message)
        return "Incident not found"
    
    def get_incident(self, incident_id: str):
        """API: Get an incident"""
        return self.incident_detector.get_incident(incident_id)
    
    def get_trace(self, incident_id: str):
        """API: Get decision trace for an incident"""
        return self._traces.get(incident_id)
    
    def get_all_incidents(self):
        """API: Get all incidents"""
        return list(self.incident_detector._active_incidents.values())
    
    def get_agent_states(self):
        """API: Get all agent states"""
        return [
            self.log_watcher.state.model_dump(),
            self.incident_detector.state.model_dump(),
            self.risk_classifier.state.model_dump(),
            self.planner.state.model_dump(),
            self.approval_agent.state.model_dump(),
            self.chat_agent.state.model_dump(),
            self.executor.state.model_dump(),
            self.memory_agent.state.model_dump()
        ]
    
    def get_stats(self):
        """API: Get memory stats"""
        return self.memory_agent.get_stats()
    
    def get_chat_history(self, incident_id: str):
        """API: Get chat history for an incident"""
        return self.chat_agent.get_chat_history(incident_id)


# Global orchestrator instance
orchestrator = Orchestrator()
