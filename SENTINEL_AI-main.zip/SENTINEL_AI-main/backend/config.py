"""
SENTINEL-AI Configuration
Central configuration management for all agents and services.
"""
import os
from dotenv import load_dotenv
from pydantic import BaseModel
from typing import Literal

load_dotenv()


class Config(BaseModel):
    """Application configuration"""
    
    # API Keys
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    use_mock_llm: bool = os.getenv("USE_MOCK_LLM", "false").lower() == "true"
    
    # Timing
    log_interval_seconds: float = float(os.getenv("LOG_INTERVAL_SECONDS", "2"))
    
    # Server
    websocket_port: int = int(os.getenv("WEBSOCKET_PORT", "8000"))
    
    # Execution
    execution_mode: Literal["simulated", "real"] = os.getenv("EXECUTION_MODE", "simulated")
    
    # Anomaly Detection
    statistical_weight: float = 0.6
    ml_weight: float = 0.4
    zscore_threshold: float = 2.0
    sliding_window_seconds: int = 30
    isolation_forest_contamination: float = 0.05
    
    # Risk Classification
    auto_execute_severities: list = ["LOW", "MEDIUM"]
    human_required_severities: list = ["HIGH", "CRITICAL"]
    
    # Services (microservices to simulate)
    services: list = ["auth-service", "api-server", "payment-service", "worker-service", "db"]


# Global config instance
config = Config()
