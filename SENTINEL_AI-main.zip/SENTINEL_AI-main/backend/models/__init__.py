"""
SENTINEL-AI Data Models
Pydantic models for logs, incidents, remediations, and decision traces.
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Literal
from datetime import datetime
from enum import Enum
import uuid


# ============================================
# ENUMS
# ============================================

class LogLevel(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class Severity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class IncidentState(str, Enum):
    DETECTED = "DETECTED"
    CLASSIFYING = "CLASSIFYING"
    AUTO_EXECUTING = "AUTO_EXECUTING"
    AWAITING_ANALYSIS = "AWAITING_ANALYSIS"
    DIAGNOSED = "DIAGNOSED"
    AWAITING_APPROVAL = "AWAITING_APPROVAL"
    MODIFIED = "MODIFIED"
    REVALIDATING = "REVALIDATING"
    APPROVED = "APPROVED"
    EXECUTING = "EXECUTING"
    RESOLVED = "RESOLVED"
    FAILED = "FAILED"
    REJECTED = "REJECTED"
    CLOSED = "CLOSED"
    ESCALATED = "ESCALATED"


class ApprovalDecision(str, Enum):
    APPROVED = "APPROVED"
    MODIFIED = "MODIFIED"
    REJECTED = "REJECTED"


# ============================================
# LOG MODEL
# ============================================

class Log(BaseModel):
    """Structured log entry from simulated services"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    service: str
    level: LogLevel
    message: str
    correlation_id: Optional[str] = None
    retry_count: int = 0
    response_time_ms: Optional[int] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


# ============================================
# METRICS MODEL
# ============================================

class ServiceMetrics(BaseModel):
    """Aggregated metrics for a service over a sliding window"""
    service: str
    window_start: datetime
    window_end: datetime
    error_rate: float = 0.0
    retry_count_avg: float = 0.0
    latency_p95: float = 0.0
    log_frequency: float = 0.0
    error_burst: float = 0.0
    total_logs: int = 0
    error_count: int = 0


# ============================================
# ANOMALY DETECTION MODELS
# ============================================

class StatisticalAnomalySignal(BaseModel):
    """Signal from Z-Score/EWMA detector"""
    detector: str = "statistical"
    metric: str
    current_value: float
    baseline: float
    z_score: float
    threshold: float
    is_anomaly: bool
    explanation: str


class MLAnomalySignal(BaseModel):
    """Signal from Isolation Forest detector"""
    detector: str = "isolation_forest"
    anomaly_score: float
    is_anomaly: bool
    feature_contributions: Dict[str, float] = Field(default_factory=dict)
    explanation: str


class AnomalyDetails(BaseModel):
    """Combined anomaly detection details"""
    statistical_signal: Optional[StatisticalAnomalySignal] = None
    ml_signal: Optional[MLAnomalySignal] = None
    combined_confidence: float = 0.0


# ============================================
# INCIDENT MODEL
# ============================================

class Incident(BaseModel):
    """Detected incident with full context"""
    incident_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    detected_at: datetime = Field(default_factory=datetime.utcnow)
    affected_service: str
    severity: Severity
    symptoms: List[str] = Field(default_factory=list)
    related_logs: List[str] = Field(default_factory=list)
    confidence_score: float = 0.0
    anomaly_details: Optional[AnomalyDetails] = None
    state: IncidentState = IncidentState.DETECTED
    
    # LLM Analysis (filled by PlannerAgent)
    root_cause: Optional[str] = None
    remediation_plan: Optional[List[Dict[str, Any]]] = None
    explanation: Optional[str] = None
    warnings: List[str] = Field(default_factory=list)
    
    # Approval tracking
    approval_decision: Optional[ApprovalDecision] = None
    decided_by: Optional[str] = None
    decided_at: Optional[datetime] = None
    modifications: Optional[str] = None
    rejection_reason: Optional[str] = None
    
    # Execution tracking
    execution_started_at: Optional[datetime] = None
    execution_completed_at: Optional[datetime] = None
    execution_result: Optional[str] = None
    execution_logs: List[str] = Field(default_factory=list)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


# ============================================
# DECISION TRACE MODEL
# ============================================

class TraceEntry(BaseModel):
    """Single entry in the decision audit trail"""
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    agent: str
    action: str
    data: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class DecisionTrace(BaseModel):
    """Complete audit trail for an incident"""
    incident_id: str
    trace: List[TraceEntry] = Field(default_factory=list)
    
    def add_entry(self, agent: str, action: str, data: Dict[str, Any] = None):
        """Add a new trace entry"""
        self.trace.append(TraceEntry(
            agent=agent,
            action=action,
            data=data or {}
        ))


# ============================================
# AGENT STATE MODEL
# ============================================

class AgentState(BaseModel):
    """Current state of an agent for observability"""
    agent_name: str
    status: Literal["idle", "processing", "waiting", "error"] = "idle"
    current_task: Optional[str] = None
    last_action: Optional[str] = None
    last_action_time: Optional[datetime] = None
    processing_incident_id: Optional[str] = None
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


# ============================================
# WEBSOCKET MESSAGE MODELS
# ============================================

class WebSocketMessage(BaseModel):
    """Message sent via WebSocket to frontend"""
    type: Literal[
        "log", 
        "incident", 
        "incident_update", 
        "agent_state", 
        "trace_entry",
        "chat_message",
        "notification"
    ]
    payload: Dict[str, Any]
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
