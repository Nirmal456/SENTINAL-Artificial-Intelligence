"""
SENTINEL-AI MemoryAgent
Stores incident history and enables learning from past incidents.
"""
from datetime import datetime
from typing import Dict, List, Optional
from collections import defaultdict

from agents.base_agent import BaseAgent
from models import Incident, IncidentState, DecisionTrace, Severity
from websocket import manager


class MemoryAgent(BaseAgent):
    """
    Stores incident history and patterns for learning.
    Provides insights from past incidents.
    """
    
    def __init__(self):
        super().__init__("MemoryAgent")
        
        # Incident storage
        self._incidents: Dict[str, Incident] = {}
        self._traces: Dict[str, DecisionTrace] = {}
        
        # Statistics
        self._stats = {
            "total_incidents": 0,
            "by_severity": defaultdict(int),
            "by_service": defaultdict(int),
            "by_state": defaultdict(int),
            "approved": 0,
            "rejected": 0,
            "auto_executed": 0,
            "avg_resolution_time_seconds": 0.0
        }
        
        # Patterns for learning
        self._patterns: Dict[str, List[Dict]] = defaultdict(list)
    
    async def start(self):
        """Start the agent"""
        await self.update_state(status="idle", current_task="Storing incident history")
        print(f"[{self.name}] Started with memory storage")
    
    async def stop(self):
        """Stop the agent"""
        await self.set_idle()
        print(f"[{self.name}] Stopped")
    
    async def store_incident(self, incident: Incident, trace: DecisionTrace):
        """
        Store an incident and its decision trace.
        Called when an incident reaches a terminal state.
        """
        await self.set_processing(f"Storing incident {incident.incident_id[:8]}", incident.incident_id)
        
        # Store incident and trace
        self._incidents[incident.incident_id] = incident
        self._traces[incident.incident_id] = trace
        
        # Update statistics
        self._update_stats(incident)
        
        # Extract patterns for learning
        self._extract_patterns(incident)
        
        # Log to trace
        await self.log_trace(
            incident.incident_id,
            "Incident stored in memory",
            {
                "final_state": incident.state.value,
                "total_incidents": self._stats["total_incidents"]
            },
            self._traces
        )
        
        await self.update_state(
            last_action=f"Stored incident {incident.incident_id[:8]}"
        )
        
        print(f"[{self.name}] Stored incident {incident.incident_id[:8]} (total: {self._stats['total_incidents']})")
        
        # Broadcast incident update to frontend
        await manager.send_incident_update(incident.model_dump())
        
        # Broadcast updated stats to frontend
        await manager.broadcast("stats", self.get_stats())
        
        await self.set_idle()
    
    def _update_stats(self, incident: Incident):
        """Update statistics with new incident"""
        self._stats["total_incidents"] += 1
        self._stats["by_severity"][incident.severity.value] += 1
        self._stats["by_service"][incident.affected_service] += 1
        self._stats["by_state"][incident.state.value] += 1
        
        if incident.approval_decision:
            if incident.approval_decision.value == "APPROVED":
                self._stats["approved"] += 1
            elif incident.approval_decision.value == "REJECTED":
                self._stats["rejected"] += 1
        
        if incident.state == IncidentState.RESOLVED and incident.severity in [Severity.LOW, Severity.MEDIUM]:
            self._stats["auto_executed"] += 1
        
        # Calculate average resolution time
        if incident.detected_at and incident.execution_completed_at:
            duration = (incident.execution_completed_at - incident.detected_at).total_seconds()
            n = self._stats["total_incidents"]
            prev_avg = self._stats["avg_resolution_time_seconds"]
            self._stats["avg_resolution_time_seconds"] = ((prev_avg * (n - 1)) + duration) / n
    
    def _extract_patterns(self, incident: Incident):
        """Extract patterns for learning from incident"""
        pattern = {
            "service": incident.affected_service,
            "severity": incident.severity.value,
            "symptoms": incident.symptoms,
            "root_cause": incident.root_cause,
            "remediation_plan": incident.remediation_plan,
            "outcome": incident.state.value,
            "confidence": incident.confidence_score
        }
        
        self._patterns[incident.affected_service].append(pattern)
    
    def get_incident(self, incident_id: str) -> Optional[Incident]:
        """Get an incident by ID"""
        return self._incidents.get(incident_id)
    
    def get_trace(self, incident_id: str) -> Optional[DecisionTrace]:
        """Get a decision trace by incident ID"""
        return self._traces.get(incident_id)
    
    def get_all_incidents(self) -> List[Incident]:
        """Get all stored incidents"""
        return list(self._incidents.values())
    
    def get_stats(self) -> Dict:
        """Get current statistics"""
        return {
            **self._stats,
            "by_severity": dict(self._stats["by_severity"]),
            "by_service": dict(self._stats["by_service"]),
            "by_state": dict(self._stats["by_state"])
        }
    
    def get_similar_incidents(self, service: str, symptoms: List[str]) -> List[Dict]:
        """
        Find similar past incidents for learning.
        Simple similarity based on service and symptom overlap.
        """
        similar = []
        
        if service in self._patterns:
            for pattern in self._patterns[service][-10:]:  # Last 10 patterns
                # Check symptom overlap
                pattern_symptoms = set(pattern.get("symptoms", []))
                query_symptoms = set(symptoms)
                overlap = len(pattern_symptoms & query_symptoms)
                
                if overlap > 0 or pattern["service"] == service:
                    similar.append({
                        **pattern,
                        "similarity_score": overlap / max(len(query_symptoms), 1)
                    })
        
        return sorted(similar, key=lambda x: x.get("similarity_score", 0), reverse=True)[:5]


# Export
memory_agent = MemoryAgent()
