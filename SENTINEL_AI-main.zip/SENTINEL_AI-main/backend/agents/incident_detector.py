"""
SENTINEL-AI IncidentDetectorAgent
Detects anomalies and creates incidents from log patterns.
"""
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Awaitable
from collections import deque

from agents.base_agent import BaseAgent
from models import (
    Log, LogLevel, Incident, Severity, IncidentState,
    AnomalyDetails, DecisionTrace
)
from services.anomaly_detection import anomaly_detector
from config import config
from websocket import manager


class IncidentDetectorAgent(BaseAgent):
    """
    Analyzes logs and anomaly signals to detect and create incidents.
    Uses hybrid anomaly detection (statistical + ML).
    """
    
    def __init__(self):
        super().__init__("IncidentDetectorAgent")
        
        # Recent logs per service for correlation
        self._recent_logs: Dict[str, deque] = {s: deque(maxlen=50) for s in config.services}
        
        # Active incidents (to avoid duplicates)
        self._active_incidents: Dict[str, Incident] = {}
        
        # Cooldown per service (avoid rapid fire incidents)
        self._cooldown: Dict[str, datetime] = {}
        self._cooldown_seconds = 30
        
        # Callback for new incidents
        self._on_incident_callback: Optional[Callable[[Incident, DecisionTrace], Awaitable[None]]] = None
        
        # Decision traces
        self._traces: Dict[str, DecisionTrace] = {}
    
    def set_incident_callback(self, callback: Callable[[Incident, DecisionTrace], Awaitable[None]]):
        """Set callback for when an incident is detected"""
        self._on_incident_callback = callback
    
    async def start(self):
        """Start the agent"""
        await self.update_state(status="idle", current_task="Waiting for logs")
        print(f"[{self.name}] Started and waiting for logs")
    
    async def stop(self):
        """Stop the agent"""
        await self.set_idle()
        print(f"[{self.name}] Stopped")
    
    async def process_log(self, log: Log):
        """
        Process an incoming log and check for incidents.
        Called by LogWatcherAgent.
        """
        await self.set_processing(f"Analyzing log from {log.service}", None)
        
        # Store log
        self._recent_logs[log.service].append(log)
        
        # Run anomaly detection
        anomaly_details = await anomaly_detector.process_log(log)
        
        # Check if we should create an incident
        if anomaly_details and anomaly_details.combined_confidence >= 0.5:
            await self._evaluate_incident(log, anomaly_details)
        
        await self.update_state(last_action=f"Processed log {log.id[:8]}")
    
    async def _evaluate_incident(self, log: Log, anomaly_details: AnomalyDetails):
        """Evaluate if an incident should be created"""
        service = log.service
        now = datetime.utcnow()
        
        # Check cooldown
        if service in self._cooldown:
            if now < self._cooldown[service]:
                return  # Still in cooldown
        
        # Check if there's already an active incident for this service
        for incident_id, incident in self._active_incidents.items():
            if incident.affected_service == service and incident.state not in [
                IncidentState.RESOLVED, IncidentState.CLOSED, IncidentState.REJECTED
            ]:
                # Add log to existing incident
                incident.related_logs.append(log.id)
                return
        
        # Create new incident
        severity = self._determine_severity(log, anomaly_details)
        symptoms = self._extract_symptoms(service, anomaly_details)
        
        incident = Incident(
            detected_at=now,
            affected_service=service,
            severity=severity,
            symptoms=symptoms,
            related_logs=[l.id for l in list(self._recent_logs[service])[-10:]],
            confidence_score=anomaly_details.combined_confidence,
            anomaly_details=anomaly_details,
            state=IncidentState.DETECTED
        )
        
        # Create decision trace
        trace = DecisionTrace(incident_id=incident.incident_id)
        
        # Add detection entry to trace
        trace.add_entry(
            agent=self.name,
            action="Incident detected",
            data={
                "service": service,
                "severity": severity.value,
                "confidence": anomaly_details.combined_confidence,
                "anomaly_details": anomaly_details.model_dump()
            }
        )
        
        # Store
        self._active_incidents[incident.incident_id] = incident
        self._traces[incident.incident_id] = trace
        self._cooldown[service] = now + timedelta(seconds=self._cooldown_seconds)
        
        # Log trace entry
        await self.log_trace(
            incident.incident_id,
            "Incident detected",
            {
                "severity": severity.value,
                "confidence": anomaly_details.combined_confidence,
                "statistical_signal": anomaly_details.statistical_signal.model_dump() if anomaly_details.statistical_signal else None,
                "ml_signal": anomaly_details.ml_signal.model_dump() if anomaly_details.ml_signal else None
            },
            self._traces
        )
        
        await self.update_state(
            last_action=f"Created incident {incident.incident_id[:8]} for {service}"
        )
        
        print(f"[{self.name}] Incident created: {incident.incident_id[:8]} - {service} - {severity.value}")
        
        # Broadcast to frontend via WebSocket
        await manager.send_incident(incident.model_dump())
        
        # Notify callback
        if self._on_incident_callback:
            await self._on_incident_callback(incident, trace)
    
    def _determine_severity(self, log: Log, anomaly_details: AnomalyDetails) -> Severity:
        """Determine incident severity based on log and anomaly signals"""
        confidence = anomaly_details.combined_confidence
        
        # Base severity on log level
        if log.level == LogLevel.CRITICAL:
            base_severity = Severity.CRITICAL
        elif log.level == LogLevel.ERROR:
            base_severity = Severity.HIGH if log.retry_count >= 3 else Severity.MEDIUM
        elif log.level == LogLevel.WARNING:
            base_severity = Severity.MEDIUM if confidence > 0.8 else Severity.LOW
        else:
            base_severity = Severity.LOW
        
        # Escalate based on z-score if available
        if anomaly_details.statistical_signal:
            z_score = abs(anomaly_details.statistical_signal.z_score)
            if z_score > 4.0 and base_severity in [Severity.LOW, Severity.MEDIUM]:
                base_severity = Severity.HIGH
            elif z_score > 5.0:
                base_severity = Severity.CRITICAL
        
        return base_severity
    
    def _extract_symptoms(self, service: str, anomaly_details: AnomalyDetails) -> List[str]:
        """Extract human-readable symptoms from anomaly details"""
        symptoms = []
        
        if anomaly_details.statistical_signal:
            sig = anomaly_details.statistical_signal
            symptoms.append(sig.explanation)
        
        if anomaly_details.ml_signal:
            sig = anomaly_details.ml_signal
            symptoms.append(sig.explanation)
        
        # Add service-specific context from recent logs
        recent = list(self._recent_logs[service])[-5:]
        error_msgs = [l.message for l in recent if l.level in [LogLevel.ERROR, LogLevel.CRITICAL]]
        if error_msgs:
            symptoms.append(f"Recent errors: {error_msgs[0][:100]}")
        
        return symptoms
    
    def get_trace(self, incident_id: str) -> Optional[DecisionTrace]:
        """Get decision trace for an incident"""
        return self._traces.get(incident_id)
    
    def get_incident(self, incident_id: str) -> Optional[Incident]:
        """Get an incident by ID"""
        return self._active_incidents.get(incident_id)
    
    def update_incident(self, incident: Incident):
        """Update an incident"""
        self._active_incidents[incident.incident_id] = incident


# Export
incident_detector = IncidentDetectorAgent()
