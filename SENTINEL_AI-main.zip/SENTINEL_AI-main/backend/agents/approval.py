"""
SENTINEL-AI ApprovalAgent
Handles human approval workflow for HIGH/CRITICAL incidents.
"""
import asyncio
from datetime import datetime
from typing import Optional, Callable, Awaitable

from agents.base_agent import BaseAgent
from models import Incident, IncidentState, ApprovalDecision, DecisionTrace
from websocket import manager

# Import notification service for WhatsApp/Email alerts
try:
    from services.notification_service import notification_service
    NOTIFICATIONS_ENABLED = True
except ImportError:
    NOTIFICATIONS_ENABLED = False
    print("[ApprovalAgent] Notification service not available")


class ApprovalAgent(BaseAgent):
    """
    Gates execution for HIGH/CRITICAL incidents.
    Requires human approval before proceeding.
    """
    
    def __init__(self):
        super().__init__("ApprovalAgent")
        self._pending_approvals: dict = {}  # incident_id -> Incident
        self._traces: dict = {}
        
        # Callbacks
        self._on_approved: Optional[Callable[[Incident, DecisionTrace], Awaitable[None]]] = None
        self._on_rejected: Optional[Callable[[Incident, DecisionTrace], Awaitable[None]]] = None
        self._on_modified: Optional[Callable[[Incident, DecisionTrace, str], Awaitable[None]]] = None
    
    def set_traces(self, traces: dict):
        """Set reference to decision traces"""
        self._traces = traces
    
    def set_approved_callback(self, callback: Callable[[Incident, DecisionTrace], Awaitable[None]]):
        """Set callback for approved incidents"""
        self._on_approved = callback
    
    def set_rejected_callback(self, callback: Callable[[Incident, DecisionTrace], Awaitable[None]]):
        """Set callback for rejected incidents"""
        self._on_rejected = callback
    
    def set_modified_callback(self, callback: Callable[[Incident, DecisionTrace, str], Awaitable[None]]):
        """Set callback for modified plans"""
        self._on_modified = callback
    
    async def start(self):
        """Start the agent"""
        await self.update_state(status="idle", current_task="Waiting for approval requests")
        print(f"[{self.name}] Started and ready for approvals")
    
    async def stop(self):
        """Stop the agent"""
        await self.set_idle()
        print(f"[{self.name}] Stopped")
    
    async def request_approval(self, incident: Incident, trace: DecisionTrace):
        """
        Request human approval for an incident.
        Called after PlannerAgent completes analysis.
        """
        await self.set_waiting(f"Awaiting human approval for {incident.incident_id[:8]}")
        
        # Update incident state
        incident.state = IncidentState.AWAITING_APPROVAL
        await manager.send_incident_update(incident.model_dump())
        
        # Store pending approval
        self._pending_approvals[incident.incident_id] = incident
        
        # Log to trace
        await self.log_trace(
            incident.incident_id,
            "Awaiting human approval",
            {
                "severity": incident.severity.value,
                "remediation_steps": len(incident.remediation_plan) if incident.remediation_plan else 0
            },
            self._traces
        )
        
        # Notify frontend
        await manager.send_notification({
            "type": "approval_required",
            "incident_id": incident.incident_id,
            "service": incident.affected_service,
            "severity": incident.severity.value,
            "message": f"Human approval required for {incident.severity.value} incident in {incident.affected_service}"
        })
        
        # Send WhatsApp + Email alerts for CRITICAL incidents
        if NOTIFICATIONS_ENABLED and incident.severity.value == "CRITICAL":
            try:
                result = await notification_service.notify_critical_incident(incident.model_dump())
                print(f"[{self.name}] Notifications sent: WhatsApp={result['whatsapp_sent']}, Email={result['email_sent']}")
            except Exception as e:
                print(f"[{self.name}] Notification failed: {e}")
        
        print(f"[{self.name}] Approval requested for {incident.incident_id[:8]}")
    
    async def approve(self, incident_id: str, decided_by: str = "human"):
        """
        Human approves the remediation plan.
        """
        if incident_id not in self._pending_approvals:
            print(f"[{self.name}] Incident {incident_id} not found in pending approvals")
            return
        
        incident = self._pending_approvals.pop(incident_id)
        
        await self.set_processing(f"Processing approval for {incident_id[:8]}", incident_id)
        
        # Update incident
        incident.approval_decision = ApprovalDecision.APPROVED
        incident.decided_by = decided_by
        incident.decided_at = datetime.utcnow()
        incident.state = IncidentState.APPROVED
        
        # Log to trace
        await self.log_trace(
            incident_id,
            "APPROVED by human",
            {
                "decided_by": decided_by,
                "decision": "APPROVED"
            },
            self._traces
        )
        
        await manager.send_incident_update(incident.model_dump())
        
        await self.update_state(
            last_action=f"Approved incident {incident_id[:8]}"
        )
        
        print(f"[{self.name}] Incident {incident_id[:8]} APPROVED")
        
        # Trigger callback
        if self._on_approved:
            trace = self._traces.get(incident_id)
            await self._on_approved(incident, trace)
        
        await self.set_idle()
    
    async def reject(self, incident_id: str, reason: str = "", decided_by: str = "human"):
        """
        Human rejects the remediation plan.
        """
        if incident_id not in self._pending_approvals:
            print(f"[{self.name}] Incident {incident_id} not found in pending approvals")
            return
        
        incident = self._pending_approvals.pop(incident_id)
        
        await self.set_processing(f"Processing rejection for {incident_id[:8]}", incident_id)
        
        # Update incident
        incident.approval_decision = ApprovalDecision.REJECTED
        incident.decided_by = decided_by
        incident.decided_at = datetime.utcnow()
        incident.rejection_reason = reason
        incident.state = IncidentState.REJECTED
        
        # Log to trace
        await self.log_trace(
            incident_id,
            "REJECTED by human",
            {
                "decided_by": decided_by,
                "decision": "REJECTED",
                "reason": reason
            },
            self._traces
        )
        
        await manager.send_incident_update(incident.model_dump())
        
        await self.update_state(
            last_action=f"Rejected incident {incident_id[:8]}"
        )
        
        print(f"[{self.name}] Incident {incident_id[:8]} REJECTED: {reason}")
        
        # Trigger callback
        if self._on_rejected:
            trace = self._traces.get(incident_id)
            await self._on_rejected(incident, trace)
        
        await self.set_idle()
    
    async def modify(self, incident_id: str, modifications: str, decided_by: str = "human"):
        """
        Human requests modifications to the plan.
        Will trigger revalidation by PlannerAgent.
        """
        if incident_id not in self._pending_approvals:
            print(f"[{self.name}] Incident {incident_id} not found in pending approvals")
            return
        
        incident = self._pending_approvals[incident_id]  # Don't pop - still pending
        
        await self.set_processing(f"Processing modification for {incident_id[:8]}", incident_id)
        
        # Update incident
        incident.approval_decision = ApprovalDecision.MODIFIED
        incident.decided_by = decided_by
        incident.decided_at = datetime.utcnow()
        incident.modifications = modifications
        incident.state = IncidentState.MODIFIED
        
        # Log to trace
        await self.log_trace(
            incident_id,
            "MODIFIED by human - revalidation required",
            {
                "decided_by": decided_by,
                "decision": "MODIFIED",
                "modifications": modifications
            },
            self._traces
        )
        
        await manager.send_incident_update(incident.model_dump())
        
        await self.update_state(
            last_action=f"Modification requested for {incident_id[:8]}"
        )
        
        print(f"[{self.name}] Incident {incident_id[:8]} MODIFIED - revalidation needed")
        
        # Trigger callback for revalidation
        if self._on_modified:
            trace = self._traces.get(incident_id)
            await self._on_modified(incident, trace, modifications)
        
        await self.set_waiting(f"Awaiting revalidation for {incident_id[:8]}")
    
    def get_pending_approvals(self) -> list:
        """Get list of pending approval incident IDs"""
        return list(self._pending_approvals.keys())


# Export
approval_agent = ApprovalAgent()
