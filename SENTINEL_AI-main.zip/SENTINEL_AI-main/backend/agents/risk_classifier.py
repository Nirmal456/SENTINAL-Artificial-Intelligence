"""
SENTINEL-AI RiskClassifierAgent
Enforces risk-based execution policies and guardrails.
"""
import asyncio
from datetime import datetime
from typing import Optional, Callable, Awaitable

from agents.base_agent import BaseAgent
from models import Incident, Severity, IncidentState, DecisionTrace
from config import config
from websocket import manager


class RiskClassifierAgent(BaseAgent):
    """
    Classifies incidents and enforces execution policy.
    Guardrails: LOW/MEDIUM → auto-execute, HIGH/CRITICAL → human required.
    """
    
    def __init__(self):
        super().__init__("RiskClassifierAgent")
        
        # Callbacks for different paths
        self._on_auto_execute: Optional[Callable[[Incident, DecisionTrace], Awaitable[None]]] = None
        self._on_human_required: Optional[Callable[[Incident, DecisionTrace], Awaitable[None]]] = None
        
        # Reference to traces
        self._traces: dict = {}
    
    def set_traces(self, traces: dict):
        """Set reference to decision traces"""
        self._traces = traces
    
    def set_auto_execute_callback(self, callback: Callable[[Incident, DecisionTrace], Awaitable[None]]):
        """Set callback for auto-execute path"""
        self._on_auto_execute = callback
    
    def set_human_required_callback(self, callback: Callable[[Incident, DecisionTrace], Awaitable[None]]):
        """Set callback for human-required path"""
        self._on_human_required = callback
    
    async def start(self):
        """Start the agent"""
        await self.update_state(status="idle", current_task="Waiting for incidents")
        print(f"[{self.name}] Started and ready to classify incidents")
    
    async def stop(self):
        """Stop the agent"""
        await self.set_idle()
        print(f"[{self.name}] Stopped")
    
    async def classify(self, incident: Incident, trace: DecisionTrace):
        """
        Classify an incident and determine execution policy.
        This is the main entry point called by IncidentDetectorAgent.
        """
        await self.set_processing(
            f"Classifying {incident.severity.value} incident",
            incident.incident_id
        )
        
        # Update incident state
        incident.state = IncidentState.CLASSIFYING
        await manager.send_incident_update(incident.model_dump())
        
        # Determine policy
        requires_human = incident.severity in [Severity.HIGH, Severity.CRITICAL]
        
        # Build policy decision
        policy = {
            "severity": incident.severity.value,
            "auto_execute": not requires_human,
            "human_required": requires_human,
            "alerts_triggered": requires_human,
            "reason": self._get_policy_reason(incident.severity)
        }
        
        # Log to trace
        await self.log_trace(
            incident.incident_id,
            f"Classified as {incident.severity.value}",
            policy,
            self._traces
        )
        
        await self.update_state(
            last_action=f"Classified {incident.incident_id[:8]} as {incident.severity.value}"
        )
        
        print(f"[{self.name}] Incident {incident.incident_id[:8]} classified: {policy}")
        
        # Route to appropriate handler
        if requires_human:
            incident.state = IncidentState.AWAITING_ANALYSIS
            await manager.send_incident_update(incident.model_dump())
            
            # Send notification about needing human attention
            await manager.send_notification({
                "type": "human_required",
                "incident_id": incident.incident_id,
                "severity": incident.severity.value,
                "service": incident.affected_service,
                "message": f"{incident.severity.value} incident requires human approval"
            })
            
            if self._on_human_required:
                await self._on_human_required(incident, trace)
        else:
            incident.state = IncidentState.AUTO_EXECUTING
            await manager.send_incident_update(incident.model_dump())
            
            if self._on_auto_execute:
                await self._on_auto_execute(incident, trace)
        
        await self.set_idle()
    
    def _get_policy_reason(self, severity: Severity) -> str:
        """Get human-readable reason for the policy decision"""
        reasons = {
            Severity.LOW: "Low severity incidents can be auto-remediated safely",
            Severity.MEDIUM: "Medium severity incidents can be auto-remediated with monitoring",
            Severity.HIGH: "High severity requires human review before remediation",
            Severity.CRITICAL: "Critical severity requires immediate human decision"
        }
        return reasons.get(severity, "Unknown severity")


# Export
risk_classifier = RiskClassifierAgent()
