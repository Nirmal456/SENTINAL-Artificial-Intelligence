"""
SENTINEL-AI Agents Package
"""
from agents.base_agent import BaseAgent
from agents.log_watcher import log_watcher, LogWatcherAgent
from agents.incident_detector import incident_detector, IncidentDetectorAgent
from agents.risk_classifier import risk_classifier, RiskClassifierAgent
from agents.executor import executor, ExecutorAgent
from agents.planner import planner, PlannerAgent
from agents.approval import approval_agent, ApprovalAgent
from agents.chat import chat_agent, ChatAgent
from agents.memory import memory_agent, MemoryAgent

__all__ = [
    "BaseAgent",
    "log_watcher", "LogWatcherAgent",
    "incident_detector", "IncidentDetectorAgent",
    "risk_classifier", "RiskClassifierAgent",
    "executor", "ExecutorAgent",
    "planner", "PlannerAgent",
    "approval_agent", "ApprovalAgent",
    "chat_agent", "ChatAgent",
    "memory_agent", "MemoryAgent"
]

