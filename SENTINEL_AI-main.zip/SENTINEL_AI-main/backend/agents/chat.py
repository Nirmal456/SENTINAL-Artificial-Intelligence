"""
SENTINEL-AI ChatAgent
Enables human-AI conversation for plan modifications.
"""
from datetime import datetime
from typing import List, Dict, Optional

from agents.base_agent import BaseAgent
from models import Incident, DecisionTrace
from services.llm_service import llm_service
from websocket import manager


class ChatAgent(BaseAgent):
    """
    Handles chat interactions between humans and AI.
    Used for discussing and modifying remediation plans.
    """
    
    def __init__(self):
        super().__init__("ChatAgent")
        
        # Chat history per incident: {incident_id: [messages]}
        self._chat_histories: Dict[str, List[Dict]] = {}
        self._traces: dict = {}
    
    def set_traces(self, traces: dict):
        """Set reference to decision traces"""
        self._traces = traces
    
    async def start(self):
        """Start the agent"""
        await self.update_state(status="idle", current_task="Waiting for chat messages")
        print(f"[{self.name}] Started and ready for chat")
    
    async def stop(self):
        """Stop the agent"""
        await self.set_idle()
        print(f"[{self.name}] Stopped")
    
    async def chat(self, incident_id: str, incident: Incident, user_message: str) -> str:
        """
        Process a chat message from the human.
        Returns AI response.
        """
        await self.set_processing(f"Processing chat for {incident_id[:8]}", incident_id)
        
        # Initialize chat history if needed
        if incident_id not in self._chat_histories:
            self._chat_histories[incident_id] = []
        
        # Add user message to history
        self._chat_histories[incident_id].append({
            "role": "user",
            "content": user_message,
            "timestamp": datetime.utcnow().isoformat()
        })
        
        # Broadcast user message
        await manager.send_chat_message({
            "incident_id": incident_id,
            "role": "user",
            "content": user_message,
            "timestamp": datetime.utcnow().isoformat()
        })
        
        try:
            # Get AI response
            incident_data = {
                "affected_service": incident.affected_service,
                "severity": incident.severity.value,
                "symptoms": incident.symptoms,
                "confidence_score": incident.confidence_score,
                "root_cause": incident.root_cause,
                "remediation_plan": incident.remediation_plan,
                "anomaly_details": incident.anomaly_details.model_dump() if incident.anomaly_details else {}
            }
            
            ai_response = await llm_service.chat(
                incident_data,
                self._chat_histories[incident_id],
                user_message
            )
            
            # Add AI response to history
            self._chat_histories[incident_id].append({
                "role": "assistant",
                "content": ai_response,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            # Broadcast AI response
            await manager.send_chat_message({
                "incident_id": incident_id,
                "role": "assistant",
                "content": ai_response,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            # Log to trace
            await self.log_trace(
                incident_id,
                "Chat message processed",
                {
                    "user_message": user_message[:100],
                    "ai_response": ai_response[:100]
                },
                self._traces
            )
            
            await self.update_state(
                last_action=f"Chat response for {incident_id[:8]}"
            )
            
            await self.set_idle()
            return ai_response
            
        except Exception as e:
            print(f"[{self.name}] Error in chat: {e}")
            error_response = "I apologize, but I encountered an error processing your message. Please try again."
            
            self._chat_histories[incident_id].append({
                "role": "assistant",
                "content": error_response,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            await manager.send_chat_message({
                "incident_id": incident_id,
                "role": "assistant",
                "content": error_response,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            await self.set_idle()
            return error_response
    
    def get_chat_history(self, incident_id: str) -> List[Dict]:
        """Get chat history for an incident"""
        return self._chat_histories.get(incident_id, [])
    
    def clear_chat_history(self, incident_id: str):
        """Clear chat history for an incident"""
        if incident_id in self._chat_histories:
            del self._chat_histories[incident_id]


# Export
chat_agent = ChatAgent()
