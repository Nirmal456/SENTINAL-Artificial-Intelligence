"""
SENTINEL-AI LogWatcherAgent
Generates realistic production logs every 2 seconds.
"""
import asyncio
import random
import uuid
from datetime import datetime
from typing import Callable, Awaitable, Optional

from agents.base_agent import BaseAgent
from models import Log, LogLevel
from config import config
from websocket import manager


# Realistic log message templates per service
LOG_TEMPLATES = {
    "auth-service": {
        LogLevel.INFO: [
            "User login successful for user_id={user_id}",
            "JWT token refreshed for session={session_id}",
            "Password validation completed",
            "OAuth callback processed successfully",
            "Session created for user_id={user_id}"
        ],
        LogLevel.WARNING: [
            "Rate limit approaching for IP {ip}",
            "Weak password detected for user_id={user_id}",
            "Token expiring in 5 minutes for session={session_id}",
            "Multiple failed login attempts from IP {ip}"
        ],
        LogLevel.ERROR: [
            "Authentication failed: invalid credentials for user_id={user_id}",
            "JWT validation error: token expired",
            "OAuth provider unreachable, retry_count={retry_count}",
            "Database connection timeout during auth check"
        ],
        LogLevel.CRITICAL: [
            "Security breach detected: brute force attack from IP {ip}",
            "Auth service database connection pool exhausted",
            "Critical: JWT secret key rotation failed"
        ]
    },
    "api-server": {
        LogLevel.INFO: [
            "GET /api/v1/users completed in {latency}ms",
            "POST /api/v1/orders processed successfully",
            "Request {request_id} handled by worker-{worker_id}",
            "Cache hit for resource /api/v1/products/{product_id}",
            "Health check passed"
        ],
        LogLevel.WARNING: [
            "Slow response: GET /api/v1/reports took {latency}ms",
            "Cache miss rate above threshold: 45%",
            "Request queue depth: 150 (threshold: 100)",
            "Memory usage at 78% of limit"
        ],
        LogLevel.ERROR: [
            "Request failed: 500 Internal Server Error for /api/v1/orders",
            "Upstream service timeout: payment-service, retry_count={retry_count}",
            "Rate limit exceeded for client_id={client_id}",
            "Request validation failed: invalid JSON payload"
        ],
        LogLevel.CRITICAL: [
            "API server out of memory, initiating graceful shutdown",
            "All worker threads unresponsive",
            "Critical: Request processing pipeline halted"
        ]
    },
    "payment-service": {
        LogLevel.INFO: [
            "Payment {payment_id} processed successfully",
            "Refund initiated for order_id={order_id}",
            "Card validation passed for transaction {txn_id}",
            "Webhook delivered to merchant {merchant_id}",
            "Daily reconciliation completed"
        ],
        LogLevel.WARNING: [
            "Payment gateway response slow: {latency}ms",
            "Card declined: insufficient funds for payment_id={payment_id}",
            "Retry queued for failed webhook delivery",
            "PCI compliance check due in 24 hours"
        ],
        LogLevel.ERROR: [
            "Payment failed: gateway error for payment_id={payment_id}, retry_count={retry_count}",
            "Fraud detection triggered for transaction {txn_id}",
            "Settlement batch processing failed",
            "Database write failed for payment record"
        ],
        LogLevel.CRITICAL: [
            "Payment gateway connection lost - all transactions halted",
            "Critical: Double-charge detected for payment_id={payment_id}",
            "PCI audit failed - immediate action required"
        ]
    },
    "worker-service": {
        LogLevel.INFO: [
            "Job {job_id} completed in {latency}ms",
            "Processing batch of 50 tasks",
            "Worker {worker_id} heartbeat: healthy",
            "Email notification sent for event {event_id}",
            "Background sync completed for user_id={user_id}"
        ],
        LogLevel.WARNING: [
            "Job {job_id} running longer than expected: {latency}ms",
            "Worker queue backlog: 200 pending jobs",
            "Memory pressure detected on worker {worker_id}",
            "Slow consumer detected for queue events"
        ],
        LogLevel.ERROR: [
            "Job {job_id} failed: maximum retries exceeded, retry_count={retry_count}",
            "Worker {worker_id} crashed, restarting",
            "Message deserialization failed for job {job_id}",
            "External API call failed for notification"
        ],
        LogLevel.CRITICAL: [
            "All workers unresponsive - job processing halted",
            "Dead letter queue overflow - 10000 failed jobs",
            "Critical: Scheduled job missed SLA by 2 hours"
        ]
    },
    "db": {
        LogLevel.INFO: [
            "Query executed in {latency}ms: SELECT * FROM users",
            "Connection pool: 45/100 active connections",
            "Backup completed successfully",
            "Index optimization completed for table orders",
            "Replication lag: 50ms"
        ],
        LogLevel.WARNING: [
            "Slow query detected: {latency}ms for complex join",
            "Connection pool usage at 80%",
            "Replication lag increased to 500ms",
            "Disk usage at 75% of capacity"
        ],
        LogLevel.ERROR: [
            "Query timeout after {latency}ms, retry_count={retry_count}",
            "Connection refused: max connections reached",
            "Deadlock detected on table payments",
            "Replication failed for replica-2"
        ],
        LogLevel.CRITICAL: [
            "Database primary node unresponsive",
            "Disk failure detected on storage volume",
            "Critical: Data corruption detected in table orders"
        ]
    }
}


class LogWatcherAgent(BaseAgent):
    """
    Generates realistic production logs at regular intervals.
    Simulates a real microservices environment.
    """
    
    def __init__(self):
        super().__init__("LogWatcherAgent")
        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._on_log_callback: Optional[Callable[[Log], Awaitable[None]]] = None
        
        # Track state for realistic scenarios
        self._incident_mode = False
        self._incident_service: Optional[str] = None
        self._incident_duration = 0
        self._correlation_id: Optional[str] = None
    
    def set_log_callback(self, callback: Callable[[Log], Awaitable[None]]):
        """Set callback for when a log is generated"""
        self._on_log_callback = callback
    
    async def start(self):
        """Start generating logs"""
        self._running = True
        await self.update_state(status="processing", current_task="Generating logs")
        self._task = asyncio.create_task(self._log_generation_loop())
        print(f"[{self.name}] Started log generation")
    
    async def stop(self):
        """Stop generating logs"""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self.set_idle()
        print(f"[{self.name}] Stopped log generation")
    
    async def _log_generation_loop(self):
        """Main loop that generates logs every interval"""
        while self._running:
            try:
                log = self._generate_log()
                
                # Broadcast to WebSocket clients
                await manager.send_log(log.model_dump())
                
                # Call callback if set (for incident detection)
                if self._on_log_callback:
                    await self._on_log_callback(log)
                
                # Update last action
                await self.update_state(
                    last_action=f"Generated {log.level.value} log for {log.service}"
                )
                
            except Exception as e:
                print(f"[{self.name}] Error generating log: {e}")
            
            await asyncio.sleep(config.log_interval_seconds)
    
    def _generate_log(self) -> Log:
        """Generate a single realistic log entry"""
        
        # Determine if we should trigger/continue an incident scenario
        if not self._incident_mode and random.random() < 0.03:  # 3% chance to start incident
            self._start_incident_scenario()
        elif self._incident_mode:
            self._incident_duration -= 1
            if self._incident_duration <= 0:
                self._end_incident_scenario()
        
        # Select service and level
        if self._incident_mode and random.random() < 0.7:
            # During incident, 70% of logs are from affected service
            service = self._incident_service
            level = self._select_incident_level()
        else:
            service = random.choice(config.services)
            level = self._select_normal_level()
        
        # Generate log
        message = self._generate_message(service, level)
        retry_count = self._generate_retry_count(level)
        response_time = self._generate_response_time(level)
        
        return Log(
            id=str(uuid.uuid4()),
            timestamp=datetime.utcnow(),
            service=service,
            level=level,
            message=message,
            correlation_id=self._correlation_id if self._incident_mode else str(uuid.uuid4()),
            retry_count=retry_count,
            response_time_ms=response_time,
            metadata={
                "incident_mode": self._incident_mode,
                "environment": "production"
            }
        )
    
    def _start_incident_scenario(self):
        """Start an incident scenario"""
        self._incident_mode = True
        self._incident_service = random.choice(config.services)
        self._incident_duration = random.randint(5, 15)  # 5-15 logs
        self._correlation_id = str(uuid.uuid4())
        print(f"[{self.name}] Starting incident scenario for {self._incident_service}")
    
    def _end_incident_scenario(self):
        """End the incident scenario"""
        print(f"[{self.name}] Ending incident scenario for {self._incident_service}")
        self._incident_mode = False
        self._incident_service = None
        self._correlation_id = None
    
    def _select_normal_level(self) -> LogLevel:
        """Select log level for normal operation"""
        r = random.random()
        if r < 0.65:
            return LogLevel.INFO
        elif r < 0.85:
            return LogLevel.WARNING
        elif r < 0.97:
            return LogLevel.ERROR
        else:
            return LogLevel.CRITICAL
    
    def _select_incident_level(self) -> LogLevel:
        """Select log level during incident"""
        r = random.random()
        if r < 0.2:
            return LogLevel.INFO
        elif r < 0.4:
            return LogLevel.WARNING
        elif r < 0.8:
            return LogLevel.ERROR
        else:
            return LogLevel.CRITICAL
    
    def _generate_message(self, service: str, level: LogLevel) -> str:
        """Generate a realistic log message"""
        templates = LOG_TEMPLATES.get(service, LOG_TEMPLATES["api-server"])
        level_templates = templates.get(level, templates[LogLevel.INFO])
        template = random.choice(level_templates)
        
        # Fill in placeholders
        return template.format(
            user_id=f"usr_{random.randint(1000, 9999)}",
            session_id=f"sess_{random.randint(10000, 99999)}",
            ip=f"192.168.{random.randint(1,255)}.{random.randint(1,255)}",
            request_id=f"req_{uuid.uuid4().hex[:8]}",
            worker_id=random.randint(1, 10),
            product_id=random.randint(100, 999),
            latency=random.randint(50, 5000) if level in [LogLevel.ERROR, LogLevel.CRITICAL, LogLevel.WARNING] 
                    else random.randint(10, 200),
            client_id=f"client_{random.randint(100, 999)}",
            payment_id=f"pay_{uuid.uuid4().hex[:8]}",
            order_id=f"ord_{random.randint(10000, 99999)}",
            txn_id=f"txn_{uuid.uuid4().hex[:8]}",
            merchant_id=f"merch_{random.randint(100, 999)}",
            job_id=f"job_{uuid.uuid4().hex[:8]}",
            event_id=f"evt_{uuid.uuid4().hex[:8]}",
            retry_count=random.randint(1, 5)
        )
    
    def _generate_retry_count(self, level: LogLevel) -> int:
        """Generate retry count based on level"""
        if level == LogLevel.INFO:
            return 0
        elif level == LogLevel.WARNING:
            return random.randint(0, 1)
        elif level == LogLevel.ERROR:
            return random.randint(1, 3)
        else:
            return random.randint(3, 5)
    
    def _generate_response_time(self, level: LogLevel) -> int:
        """Generate response time based on level"""
        if level == LogLevel.INFO:
            return random.randint(10, 200)
        elif level == LogLevel.WARNING:
            return random.randint(200, 1000)
        elif level == LogLevel.ERROR:
            return random.randint(500, 3000)
        else:
            return random.randint(2000, 10000)


# Export
log_watcher = LogWatcherAgent()
