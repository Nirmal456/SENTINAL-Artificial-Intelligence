"""
SENTINEL-AI PlannerAgent
LLM-powered root cause analysis and remediation planning.
"""
import asyncio
from datetime import datetime
from typing import Dict, Any, Optional

from agents.base_agent import BaseAgent
from models import Incident, IncidentState, DecisionTrace
from services.llm_service import llm_service
from websocket import manager


class PlannerAgent(BaseAgent):
    """
    Uses LLM (Gemini or Mock) for root cause analysis and remediation planning.
    NEVER executes actions - only suggests.
    """
    
    def __init__(self):
        super().__init__("PlannerAgent")
        self._traces: dict = {}
    
    def set_traces(self, traces: dict):
        """Set reference to decision traces"""
        self._traces = traces
    
    async def start(self):
        """Start the agent"""
        await self.update_state(status="idle", current_task="Waiting for incidents to analyze")
        print(f"[{self.name}] Started and ready for analysis")
    
    async def stop(self):
        """Stop the agent"""
        await self.set_idle()
        print(f"[{self.name}] Stopped")
    
    async def analyze(self, incident: Incident, trace: DecisionTrace) -> Dict[str, Any]:
        """
        Analyze an incident using LLM.
        Returns the diagnosis and remediation plan.
        """
        await self.set_processing(
            f"Analyzing {incident.severity.value} incident",
            incident.incident_id
        )
        
        # Update incident state
        incident.state = IncidentState.AWAITING_ANALYSIS
        await manager.send_incident_update(incident.model_dump())
        
        try:
            # Prepare incident data for LLM
            incident_data = {
                "affected_service": incident.affected_service,
                "severity": incident.severity.value,
                "symptoms": incident.symptoms,
                "confidence_score": incident.confidence_score,
                "anomaly_details": incident.anomaly_details.model_dump() if incident.anomaly_details else {}
            }
            
            # Call LLM service
            result = await llm_service.analyze_incident(incident_data)
            
            # Update incident with analysis
            incident.root_cause = result.get("root_cause")
            incident.remediation_plan = result.get("remediation_plan", [])
            incident.explanation = result.get("explanation")
            incident.warnings = result.get("warnings", [])
            incident.state = IncidentState.DIAGNOSED
            
            # Log to trace
            await self.log_trace(
                incident.incident_id,
                "Diagnosis complete",
                {
                    "root_cause": incident.root_cause,
                    "confidence": result.get("confidence", 0.0),
                    "remediation_steps": len(incident.remediation_plan),
                    "warnings": incident.warnings
                },
                self._traces
            )
            
            await manager.send_incident_update(incident.model_dump())
            
            await self.update_state(
                last_action=f"Diagnosed incident {incident.incident_id[:8]}"
            )
            
            print(f"[{self.name}] Analysis complete for {incident.incident_id[:8]}")
            
            await self.set_idle()
            return result
            
        except Exception as e:
            print(f"[{self.name}] Error analyzing incident: {e}")
            
            # Log error to trace
            await self.log_trace(
                incident.incident_id,
                "Analysis failed",
                {"error": str(e)},
                self._traces
            )
            
            await self.set_error(f"Analysis failed: {str(e)}")
            raise
    
    async def revalidate(
        self, 
        incident: Incident, 
        trace: DecisionTrace,
        modifications: str
    ) -> Dict[str, Any]:
        """
        Revalidate a plan after human modifications.
        Called when human modifies the remediation plan.
        """
        await self.set_processing(
            f"Revalidating modified plan",
            incident.incident_id
        )
        
        incident.state = IncidentState.REVALIDATING
        await manager.send_incident_update(incident.model_dump())
        
        try:
            # Prepare data
            incident_data = {
                "affected_service": incident.affected_service,
                "severity": incident.severity.value,
                "symptoms": incident.symptoms,
                "confidence_score": incident.confidence_score,
                "anomaly_details": incident.anomaly_details.model_dump() if incident.anomaly_details else {}
            }
            
            # Call LLM for revalidation
            result = await llm_service.revalidate_plan(
                incident_data,
                incident.remediation_plan,
                modifications
            )
            
            # Update incident
            incident.root_cause = result.get("root_cause", incident.root_cause)
            incident.remediation_plan = result.get("remediation_plan", incident.remediation_plan)
            incident.explanation = result.get("explanation", incident.explanation)
            incident.warnings = result.get("warnings", incident.warnings)
            incident.state = IncidentState.AWAITING_APPROVAL
            
            # Log to trace
            await self.log_trace(
                incident.incident_id,
                "Plan revalidated after modification",
                {
                    "modifications": modifications,
                    "new_plan_steps": len(incident.remediation_plan)
                },
                self._traces
            )
            
            await manager.send_incident_update(incident.model_dump())
            
            await self.update_state(
                last_action=f"Revalidated plan for {incident.incident_id[:8]}"
            )
            
            await self.set_idle()
            return result
            
        except Exception as e:
            print(f"[{self.name}] Error revalidating plan: {e}")
            await self.set_error(f"Revalidation failed: {str(e)}")
            raise


# Export
planner = PlannerAgent()
