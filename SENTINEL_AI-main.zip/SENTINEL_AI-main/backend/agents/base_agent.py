"""
SENTINEL-AI Base Agent
Abstract base class for all agents with common functionality.
"""
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any
from datetime import datetime
import asyncio

from models import AgentState, TraceEntry
from websocket import manager


class BaseAgent(ABC):
    """
    Base class for all SENTINEL-AI agents.
    Provides common functionality for state management, observability, and tracing.
    """
    
    def __init__(self, name: str):
        self.name = name
        self._state = AgentState(
            agent_name=name,
            status="idle",
            current_task=None,
            last_action=None,
            last_action_time=None,
            processing_incident_id=None
        )
        self._running = False
    
    @property
    def state(self) -> AgentState:
        """Get current agent state"""
        return self._state
    
    async def update_state(
        self,
        status: str = None,
        current_task: str = None,
        last_action: str = None,
        processing_incident_id: str = None
    ):
        """Update agent state and broadcast to frontend"""
        if status:
            self._state.status = status
        if current_task is not None:
            self._state.current_task = current_task
        if last_action:
            self._state.last_action = last_action
            self._state.last_action_time = datetime.utcnow()
        if processing_incident_id is not None:
            self._state.processing_incident_id = processing_incident_id
        
        # Broadcast state update
        await manager.send_agent_state(self._state.model_dump())
    
    async def log_trace(
        self,
        incident_id: str,
        action: str,
        data: Dict[str, Any] = None,
        trace_store: Dict = None
    ):
        """
        Log an action to the decision trace.
        Also broadcasts the trace entry to frontend.
        """
        entry = TraceEntry(
            timestamp=datetime.utcnow(),
            agent=self.name,
            action=action,
            data=data or {}
        )
        
        # Store in trace if provided
        if trace_store is not None and incident_id in trace_store:
            trace_store[incident_id].trace.append(entry)
        
        # Broadcast to frontend
        await manager.send_trace_entry({
            "incident_id": incident_id,
            "entry": entry.model_dump()
        })
        
        return entry
    
    @abstractmethod
    async def start(self):
        """Start the agent's main loop or processing"""
        pass
    
    @abstractmethod
    async def stop(self):
        """Stop the agent gracefully"""
        pass
    
    async def set_idle(self):
        """Set agent to idle state"""
        await self.update_state(
            status="idle",
            current_task=None,
            processing_incident_id=None
        )
    
    async def set_processing(self, task: str, incident_id: str = None):
        """Set agent to processing state"""
        await self.update_state(
            status="processing",
            current_task=task,
            processing_incident_id=incident_id
        )
    
    async def set_waiting(self, reason: str):
        """Set agent to waiting state"""
        await self.update_state(
            status="waiting",
            current_task=reason
        )
    
    async def set_error(self, error: str):
        """Set agent to error state"""
        await self.update_state(
            status="error",
            current_task=error
        )
