"""
SENTINEL-AI ExecutorAgent
Executes approved or auto-approved remediation steps.
All executions are SIMULATED by default for safety.
"""
import asyncio
import random
from datetime import datetime
from typing import Dict, List, Optional

from agents.base_agent import BaseAgent
from models import Incident, IncidentState, DecisionTrace, Severity
from config import config
from websocket import manager


# Simulated remediation actions per service
REMEDIATION_ACTIONS = {
    "auth-service": [
        "Restart auth-service pods (0/3 → 3/3)",
        "Clear authentication cache",
        "Rotate JWT signing keys",
        "Reset rate limit counters",
        "Flush session store"
    ],
    "api-server": [
        "Scale api-server replicas (3 → 5)",
        "Clear API response cache",
        "Restart unhealthy pods",
        "Reset circuit breakers",
        "Flush request queue"
    ],
    "payment-service": [
        "Retry failed payment webhooks",
        "Reset payment gateway connection",
        "Clear transaction cache",
        "Restart payment processor",
        "Flush pending settlement batch"
    ],
    "worker-service": [
        "Restart worker pods (0/5 → 5/5)",
        "Clear job queue backlog",
        "Reset worker heartbeats",
        "Reprocess failed jobs",
        "Scale worker pool (5 → 8)"
    ],
    "db": [
        "Kill long-running queries",
        "Clear connection pool",
        "Restart replica synchronization",
        "Optimize slow query indexes",
        "Failover to standby replica"
    ]
}


class ExecutorAgent(BaseAgent):
    """
    Executes remediation actions for incidents.
    All executions are SIMULATED for safety in demo mode.
    """
    
    def __init__(self):
        super().__init__("ExecutorAgent")
        self._execution_mode = config.execution_mode
        self._traces: dict = {}
    
    def set_traces(self, traces: dict):
        """Set reference to decision traces"""
        self._traces = traces
    
    async def start(self):
        """Start the agent"""
        await self.update_state(status="idle", current_task="Waiting for execution requests")
        print(f"[{self.name}] Started in {self._execution_mode} mode")
    
    async def stop(self):
        """Stop the agent"""
        await self.set_idle()
        print(f"[{self.name}] Stopped")
    
    async def execute(self, incident: Incident, trace: DecisionTrace, plan: List[Dict] = None):
        """
        Execute remediation for an incident.
        Uses the provided plan or generates a default one.
        """
        await self.set_processing(
            f"Executing remediation for {incident.affected_service}",
            incident.incident_id
        )
        
        # Update incident state
        incident.state = IncidentState.EXECUTING
        incident.execution_started_at = datetime.utcnow()
        await manager.send_incident_update(incident.model_dump())
        
        # Get remediation plan
        if plan:
            actions = plan
        elif incident.remediation_plan:
            actions = incident.remediation_plan
        else:
            actions = self._generate_default_plan(incident)
        
        # Log start
        await self.log_trace(
            incident.incident_id,
            f"Execution started ({self._execution_mode})",
            {"actions_count": len(actions), "mode": self._execution_mode},
            self._traces
        )
        
        # Execute each action
        execution_logs = []
        success = True
        
        for i, action in enumerate(actions):
            action_desc = action.get("action", str(action)) if isinstance(action, dict) else str(action)
            
            await self.update_state(
                current_task=f"Step {i+1}/{len(actions)}: {action_desc[:50]}..."
            )
            
            # Simulate execution time
            await asyncio.sleep(random.uniform(0.5, 1.5))
            
            # Simulate result (high success rate)
            step_success = random.random() < 0.95
            
            log_entry = {
                "step": i + 1,
                "action": action_desc,
                "status": "SUCCESS" if step_success else "FAILED",
                "timestamp": datetime.utcnow().isoformat(),
                "mode": f"[{self._execution_mode.upper()}]"
            }
            execution_logs.append(f"[{self._execution_mode.upper()}] Step {i+1}: {action_desc} - {'SUCCESS' if step_success else 'FAILED'}")
            
            # Broadcast step progress
            await manager.send_notification({
                "type": "execution_step",
                "incident_id": incident.incident_id,
                "step": log_entry
            })
            
            if not step_success:
                success = False
                # Continue anyway for demo purposes
        
        # Update incident
        incident.execution_completed_at = datetime.utcnow()
        incident.execution_logs = execution_logs
        
        if success:
            incident.state = IncidentState.RESOLVED
            incident.execution_result = "All remediation steps completed successfully"
        else:
            incident.state = IncidentState.FAILED
            incident.execution_result = "Some remediation steps failed"
        
        # Log completion
        await self.log_trace(
            incident.incident_id,
            f"Execution completed: {incident.state.value}",
            {
                "success": success,
                "duration_seconds": (incident.execution_completed_at - incident.execution_started_at).total_seconds(),
                "logs": execution_logs
            },
            self._traces
        )
        
        await manager.send_incident_update(incident.model_dump())
        
        await self.update_state(
            last_action=f"Executed remediation for {incident.incident_id[:8]}: {incident.state.value}"
        )
        
        print(f"[{self.name}] Execution completed for {incident.incident_id[:8]}: {incident.state.value}")
        
        await self.set_idle()
        
        return success
    
    def _generate_default_plan(self, incident: Incident) -> List[Dict]:
        """Generate a default remediation plan based on service and severity"""
        service = incident.affected_service
        actions = REMEDIATION_ACTIONS.get(service, REMEDIATION_ACTIONS["api-server"])
        
        # Select actions based on severity
        if incident.severity in [Severity.LOW, Severity.MEDIUM]:
            selected = actions[:2]
        else:
            selected = actions[:4]
        
        return [{"step": i+1, "action": a, "risk": "LOW"} for i, a in enumerate(selected)]


# Export
executor = ExecutorAgent()
