import { AGENT_STATUS_COLORS } from '../utils/constants'
import './AgentObserver.css'

// Agent descriptions for clarity
const AGENT_INFO = {
    'LogWatcherAgent': {
        icon: '📡',
        shortName: 'Log Watcher',
        description: 'Monitors logs from all services'
    },
    'IncidentDetectorAgent': {
        icon: '🔍',
        shortName: 'Detector',
        description: 'Detects anomalies using AI'
    },
    'RiskClassifierAgent': {
        icon: '⚖️',
        shortName: 'Risk Classifier',
        description: 'Classifies severity (LOW→CRITICAL)'
    },
    'PlannerAgent': {
        icon: '🧠',
        shortName: 'AI Planner',
        description: 'Analyzes root cause with Gemini'
    },
    'ApprovalAgent': {
        icon: '✋',
        shortName: 'Approval Gate',
        description: 'Requires human for HIGH/CRITICAL'
    },
    'ChatAgent': {
        icon: '💬',
        shortName: 'Chat',
        description: 'Human-AI conversation'
    },
    'ExecutorAgent': {
        icon: '⚡',
        shortName: 'Executor',
        description: 'Runs remediation (simulated)'
    },
    'MemoryAgent': {
        icon: '💾',
        shortName: 'Memory',
        description: 'Stores incident history'
    }
}

export default function AgentObserver({ agents }) {
    const getAgentInfo = (name) => {
        return AGENT_INFO[name] || { icon: '🤖', shortName: name, description: 'Agent' }
    }

    const getStatusLabel = (status) => {
        switch (status) {
            case 'processing': return '● ACTIVE'
            case 'waiting': return '◐ WAITING'
            case 'error': return '✕ ERROR'
            default: return '○ ONLINE'
        }
    }

    return (
        <div className="panel agent-observer">
            <div className="panel-header">
                <span className="panel-title">🤖 Agent Observability</span>
                <span className="panel-badge">{agents.length} agents</span>
            </div>
            <div className="agents-list">
                {agents.length === 0 ? (
                    <div className="no-data">Connecting to agents...</div>
                ) : (
                    agents.map((agent) => {
                        const info = getAgentInfo(agent.agent_name)
                        return (
                            <div
                                key={agent.agent_name}
                                className={`agent-row ${agent.status}`}
                            >
                                <div className="agent-icon">{info.icon}</div>
                                <div className="agent-info">
                                    <div className="agent-name-row">
                                        <span className="agent-short-name">{info.shortName}</span>
                                        <span
                                            className={`agent-status-label ${agent.status}`}
                                            style={{ color: AGENT_STATUS_COLORS[agent.status] }}
                                        >
                                            {getStatusLabel(agent.status)}
                                        </span>
                                    </div>
                                    <div className="agent-task">
                                        {agent.current_task || info.description}
                                    </div>
                                </div>
                            </div>
                        )
                    })
                )}
            </div>

            {/* Legend */}
            <div className="agent-legend">
                <span className="legend-item"><span style={{ color: 'var(--status-processing)' }}>●</span> Active</span>
                <span className="legend-item"><span style={{ color: 'var(--status-waiting)' }}>◐</span> Waiting</span>
                <span className="legend-item"><span style={{ color: 'var(--status-idle)' }}>○</span> Online</span>
            </div>
        </div>
    )
}
