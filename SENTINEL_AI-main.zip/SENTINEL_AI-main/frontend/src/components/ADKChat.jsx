import { useState, useRef, useEffect } from 'react'
import './ADKChat.css'

export default function ADKChat() {
    const [messages, setMessages] = useState([])
    const [input, setInput] = useState('')
    const [isLoading, setIsLoading] = useState(false)
    const [sessionId] = useState(() => `session_${Date.now()}`)
    const messagesEndRef = useRef(null)

    // Auto-scroll to bottom
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    }, [messages])

    const sendMessage = async () => {
        if (!input.trim() || isLoading) return

        const userMessage = input.trim()
        setInput('')

        // Add user message
        setMessages(prev => [...prev, {
            role: 'user',
            content: userMessage,
            timestamp: new Date().toISOString()
        }])

        setIsLoading(true)

        try {
            const response = await fetch('http://localhost:8001/api/adk-chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: userMessage,
                    session_id: sessionId
                })
            })

            const data = await response.json()

            // Add AI response
            setMessages(prev => [...prev, {
                role: 'assistant',
                content: data.response,
                tool_calls: data.tool_calls || [],
                timestamp: new Date().toISOString()
            }])
        } catch (error) {
            setMessages(prev => [...prev, {
                role: 'error',
                content: `Error: ${error.message}`,
                timestamp: new Date().toISOString()
            }])
        }

        setIsLoading(false)
    }

    const handleKeyPress = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault()
            sendMessage()
        }
    }

    const clearChat = async () => {
        try {
            await fetch(`http://localhost:8001/api/adk-chat/${sessionId}`, {
                method: 'DELETE'
            })
            setMessages([])
        } catch (error) {
            console.error('Failed to clear chat:', error)
        }
    }

    return (
        <div className="panel adk-chat">
            <div className="panel-header">
                <span className="panel-title">🤖 ADK Agent Chat</span>
                <button className="btn btn-sm btn-outline" onClick={clearChat}>
                    Clear
                </button>
            </div>

            <div className="chat-messages-container">
                {messages.length === 0 ? (
                    <div className="chat-welcome">
                        <div className="welcome-icon">🧠</div>
                        <h3>SENTINEL-AI Agent</h3>
                        <p>Ask me about incidents, services, or remediation plans.</p>
                        <div className="example-prompts">
                            <div className="example" onClick={() => setInput("What's the status of the payment service?")}>
                                💡 What's the status of the payment service?
                            </div>
                            <div className="example" onClick={() => setInput("Analyze the last critical incident")}>
                                💡 Analyze the last critical incident
                            </div>
                            <div className="example" onClick={() => setInput("Show incident history for db service")}>
                                💡 Show incident history for db service
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="chat-messages">
                        {messages.map((msg, i) => (
                            <div key={i} className={`chat-message ${msg.role}`}>
                                <div className="message-header">
                                    <span className="message-role">
                                        {msg.role === 'user' ? '👤 You' : msg.role === 'error' ? '❌ Error' : '🤖 SENTINEL-AI'}
                                    </span>
                                    <span className="message-time">
                                        {new Date(msg.timestamp).toLocaleTimeString()}
                                    </span>
                                </div>
                                <div className="message-content">
                                    <pre>{msg.content}</pre>
                                </div>
                                {msg.tool_calls && msg.tool_calls.length > 0 && (
                                    <div className="tool-calls">
                                        <span className="tool-label">Tools Used:</span>
                                        {msg.tool_calls.map((tool, j) => (
                                            <span key={j} className={`tool-badge ${tool.status}`}>
                                                🔧 {tool.name}
                                            </span>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ))}
                        {isLoading && (
                            <div className="chat-message assistant loading">
                                <div className="message-header">
                                    <span className="message-role">🤖 SENTINEL-AI</span>
                                </div>
                                <div className="message-content">
                                    <div className="typing-indicator">
                                        <span></span><span></span><span></span>
                                    </div>
                                </div>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>
                )}
            </div>

            <div className="chat-input-container">
                <input
                    type="text"
                    placeholder="Ask SENTINEL-AI about incidents..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    disabled={isLoading}
                />
                <button
                    className="btn btn-primary"
                    onClick={sendMessage}
                    disabled={isLoading || !input.trim()}
                >
                    {isLoading ? '...' : 'Send'}
                </button>
            </div>
        </div>
    )
}
