import { useState } from 'react'
import { SEVERITY_COLORS, INCIDENT_STATES } from '../utils/constants'
import './IncidentDetails.css'

export default function IncidentDetails({
    incident,
    onApprove,
    onReject,
    onModify,
    onChat,
    chatMessages,
    onClose,
    onSwitchToChat
}) {
    const [chatInput, setChatInput] = useState('')
    const [modifyInput, setModifyInput] = useState('')
    const [showModify, setShowModify] = useState(false)
    const [rejectReason, setRejectReason] = useState('')
    const [showReject, setShowReject] = useState(false)

    if (!incident) {
        return (
            <div className="panel incident-details">
                <div className="panel-header">
                    <span className="panel-title">📋 Incident Details</span>
                </div>
                <div className="no-data">Select an incident to view details</div>
            </div>
        )
    }

    const stateInfo = INCIDENT_STATES[incident.state] || { label: incident.state }
    const needsApproval = incident.state === 'AWAITING_APPROVAL'
    const messages = chatMessages[incident.incident_id] || []

    const handleApprove = () => {
        onApprove(incident.incident_id)
    }

    const handleReject = () => {
        if (showReject) {
            onReject(incident.incident_id, rejectReason)
            setShowReject(false)
            setRejectReason('')
        } else {
            setShowReject(true)
        }
    }

    const handleModify = () => {
        if (showModify && modifyInput.trim()) {
            onModify(incident.incident_id, modifyInput)
            setShowModify(false)
            setModifyInput('')
        } else {
            setShowModify(true)
        }
    }

    const handleChat = () => {
        if (chatInput.trim()) {
            onChat(incident.incident_id, chatInput)
            setChatInput('')
        }
    }

    const handleKeyPress = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault()
            handleChat()
        }
    }

    return (
        <div className="panel incident-details">
            <div className="panel-header">
                <span className="panel-title">📋 Incident Details</span>
                <button className="btn btn-sm btn-outline" onClick={onClose}>✕</button>
            </div>

            <div className="details-content">
                {/* Header Info */}
                <div className="details-header">
                    <span
                        className="severity-badge"
                        style={{ background: SEVERITY_COLORS[incident.severity] }}
                    >
                        {incident.severity}
                    </span>
                    <span className="service-name">{incident.affected_service}</span>
                    <span
                        className="state-badge"
                        style={{ color: stateInfo.color, borderColor: stateInfo.color }}
                    >
                        {stateInfo.label}
                    </span>
                </div>

                {/* Symptoms */}
                <div className="details-section">
                    <h4>Symptoms</h4>
                    <ul className="symptoms-list">
                        {incident.symptoms?.map((s, i) => (
                            <li key={i}>{s}</li>
                        ))}
                    </ul>
                </div>

                {/* Agent Timeline - Shows what each agent did */}
                <div className="details-section agent-timeline">
                    <h4>🤖 Agent Activity Timeline</h4>
                    <div className="timeline">
                        {/* Detection Agent */}
                        <div className="timeline-item completed">
                            <div className="timeline-icon">🔍</div>
                            <div className="timeline-content">
                                <span className="timeline-agent">Incident Detector</span>
                                <span className="timeline-action">
                                    Detected anomaly in <strong>{incident.affected_service}</strong>
                                    {incident.confidence_score && ` (${Math.round(incident.confidence_score * 100)}% confidence)`}
                                </span>
                                {incident.anomaly_details?.statistical_signal && (
                                    <span className="timeline-detail">
                                        Z-Score: {incident.anomaly_details.statistical_signal.z_score?.toFixed(2)} |
                                        {incident.anomaly_details.statistical_signal.explanation}
                                    </span>
                                )}
                            </div>
                        </div>

                        {/* Risk Classifier */}
                        <div className="timeline-item completed">
                            <div className="timeline-icon">⚖️</div>
                            <div className="timeline-content">
                                <span className="timeline-agent">Risk Classifier</span>
                                <span className="timeline-action">
                                    Classified as <strong style={{ color: SEVERITY_COLORS[incident.severity] }}>{incident.severity}</strong>
                                    {incident.severity === 'LOW' || incident.severity === 'MEDIUM'
                                        ? ' → Auto-execute allowed'
                                        : ' → Human approval required'}
                                </span>
                            </div>
                        </div>

                        {/* Planner (only for HIGH/CRITICAL) */}
                        {(incident.severity === 'HIGH' || incident.severity === 'CRITICAL') && (
                            <div className={`timeline-item ${incident.root_cause ? 'completed' : 'pending'}`}>
                                <div className="timeline-icon">🧠</div>
                                <div className="timeline-content">
                                    <span className="timeline-agent">AI Planner (Gemini)</span>
                                    <span className="timeline-action">
                                        {incident.root_cause
                                            ? 'Analyzed root cause and generated remediation plan'
                                            : 'Analyzing incident...'}
                                    </span>
                                    {incident.root_cause && (
                                        <span className="timeline-detail">
                                            Root cause identified: {incident.root_cause.substring(0, 100)}...
                                        </span>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* Approval (only for HIGH/CRITICAL) */}
                        {(incident.severity === 'HIGH' || incident.severity === 'CRITICAL') && (
                            <div className={`timeline-item ${incident.state === 'AWAITING_APPROVAL' ? 'active' :
                                incident.approval_decision ? 'completed' : 'pending'
                                }`}>
                                <div className="timeline-icon">✋</div>
                                <div className="timeline-content">
                                    <span className="timeline-agent">Approval Gate</span>
                                    <span className="timeline-action">
                                        {incident.state === 'AWAITING_APPROVAL'
                                            ? '⏳ Waiting for human decision...'
                                            : incident.approval_decision === 'APPROVED'
                                                ? `✓ Approved by ${incident.decided_by || 'human'}`
                                                : incident.approval_decision === 'REJECTED'
                                                    ? `✕ Rejected: ${incident.rejection_reason || 'No reason given'}`
                                                    : 'Pending approval'}
                                    </span>
                                </div>
                            </div>
                        )}

                        {/* Executor */}
                        <div className={`timeline-item ${incident.state === 'RESOLVED' ? 'completed' :
                            incident.state === 'EXECUTING' ? 'active' : 'pending'
                            }`}>
                            <div className="timeline-icon">⚡</div>
                            <div className="timeline-content">
                                <span className="timeline-agent">Executor</span>
                                <span className="timeline-action">
                                    {incident.state === 'RESOLVED'
                                        ? `✓ Remediation executed successfully`
                                        : incident.state === 'EXECUTING'
                                            ? '⏳ Executing remediation...'
                                            : incident.state === 'FAILED'
                                                ? `✕ Execution failed: ${incident.error_message || 'Unknown error'}`
                                                : 'Pending execution'}
                                </span>
                                {incident.execution_logs?.length > 0 && (
                                    <span className="timeline-detail">
                                        {incident.execution_logs.length} steps completed
                                    </span>
                                )}
                            </div>
                        </div>

                        {/* Memory */}
                        <div className={`timeline-item ${incident.state === 'RESOLVED' || incident.state === 'REJECTED' ? 'completed' : 'pending'
                            }`}>
                            <div className="timeline-icon">💾</div>
                            <div className="timeline-content">
                                <span className="timeline-agent">Memory</span>
                                <span className="timeline-action">
                                    {incident.state === 'RESOLVED' || incident.state === 'REJECTED'
                                        ? 'Incident stored for future learning'
                                        : 'Pending storage'}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* AI Analysis */}
                {incident.root_cause && (
                    <div className="details-section ai-analysis">
                        <h4>🤖 AI Analysis</h4>
                        <div className="analysis-box">
                            <div className="analysis-item">
                                <span className="label">Root Cause:</span>
                                <p>{incident.root_cause}</p>
                            </div>
                            {incident.explanation && (
                                <div className="analysis-item">
                                    <span className="label">Explanation:</span>
                                    <p>{incident.explanation}</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* Remediation Plan */}
                {incident.remediation_plan && incident.remediation_plan.length > 0 && (
                    <div className="details-section">
                        <h4>🔧 Remediation Plan</h4>
                        <div className="remediation-steps">
                            {incident.remediation_plan.map((step, i) => (
                                <div key={i} className="step">
                                    <span className="step-num">{step.step || i + 1}</span>
                                    <span className="step-action">{step.action}</span>
                                    <span
                                        className={`step-risk risk-${step.risk?.toLowerCase()}`}
                                    >
                                        {step.risk}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Warnings */}
                {incident.warnings && incident.warnings.length > 0 && (
                    <div className="details-section warnings">
                        <h4>⚠️ Warnings</h4>
                        <ul>
                            {incident.warnings.map((w, i) => (
                                <li key={i}>{w}</li>
                            ))}
                        </ul>
                    </div>
                )}

                {/* Execution Logs */}
                {incident.execution_logs && incident.execution_logs.length > 0 && (
                    <div className="details-section">
                        <h4>📝 Execution Logs</h4>
                        <div className="execution-logs">
                            {incident.execution_logs.map((log, i) => (
                                <div key={i} className="exec-log">{log}</div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Approval Actions */}
                {needsApproval && (
                    <div className="approval-section">
                        <h4>Human Decision Required</h4>

                        {showModify && (
                            <div className="modify-input">
                                <textarea
                                    placeholder="Describe your modifications to the plan..."
                                    value={modifyInput}
                                    onChange={(e) => setModifyInput(e.target.value)}
                                />
                            </div>
                        )}

                        {showReject && (
                            <div className="reject-input">
                                <input
                                    type="text"
                                    placeholder="Reason for rejection (optional)"
                                    value={rejectReason}
                                    onChange={(e) => setRejectReason(e.target.value)}
                                />
                            </div>
                        )}

                        <div className="approval-buttons">
                            <button className="btn btn-success" onClick={handleApprove}>
                                ✓ Approve
                            </button>
                            <button
                                className={`btn ${showModify ? 'btn-primary' : 'btn-outline'}`}
                                onClick={handleModify}
                            >
                                ✎ {showModify ? 'Submit' : 'Modify'}
                            </button>
                            <button
                                className={`btn ${showReject ? 'btn-danger' : 'btn-outline'}`}
                                onClick={handleReject}
                            >
                                ✕ {showReject ? 'Confirm Reject' : 'Reject'}
                            </button>
                        </div>
                    </div>
                )}

                {/* Chat Interface - Navigate to ADK Chat */}
                <div className="chat-section">
                    <h4>💬 Chat with AI</h4>
                    <div className="chat-redirect">
                        <p className="redirect-message">
                            For detailed AI analysis and conversation about this incident, use the ADK Chat in the Agents tab.
                        </p>
                        <button
                            className="btn btn-primary"
                            onClick={() => {
                                if (onSwitchToChat) {
                                    onSwitchToChat()
                                } else {
                                    onClose()
                                }
                            }}
                            style={{
                                width: '100%',
                                marginTop: '1rem',
                                background: 'var(--accent-gradient)',
                                border: 'none',
                                padding: '0.75rem',
                                fontSize: '1rem',
                                fontWeight: '600'
                            }}
                        >
                            🤖 Go to ADK Chat →
                        </button>
                        <p className="redirect-hint" style={{
                            marginTop: '0.5rem',
                            fontSize: '0.75rem',
                            color: 'var(--text-muted)',
                            textAlign: 'center'
                        }}>
                            Click the "💬 ADK Chat" tab above to start chatting
                        </p>
                    </div>
                </div>
            </div>
        </div>
    )
}
