import { useRef, useEffect } from 'react'
import { LOG_LEVEL_COLORS } from '../utils/constants'
import './LogStream.css'

export default function LogStream({ logs }) {
    const containerRef = useRef(null)

    useEffect(() => {
        if (containerRef.current) {
            containerRef.current.scrollTop = containerRef.current.scrollHeight
        }
    }, [logs])

    const formatTime = (timestamp) => {
        const date = new Date(timestamp)
        return date.toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        })
    }

    return (
        <div className="panel log-stream">
            <div className="panel-header">
                <span className="panel-title">📡 Real-Time Logs</span>
                <span className="panel-badge">{logs.length}</span>
            </div>
            <div className="log-container" ref={containerRef}>
                {logs.length === 0 ? (
                    <div className="no-data">Waiting for logs...</div>
                ) : (
                    logs.map((log, index) => (
                        <div
                            key={log.id || index}
                            className="log-entry animate-slide-in"
                            data-level={log.level}
                        >
                            <span className="log-time">{formatTime(log.timestamp)}</span>
                            <span
                                className="log-level"
                                style={{ color: LOG_LEVEL_COLORS[log.level] }}
                            >
                                [{log.level}]
                            </span>
                            <span className="log-service">{log.service}</span>
                            <span className="log-message">{log.message}</span>
                            {log.retry_count > 0 && (
                                <span className="log-retry">retry:{log.retry_count}</span>
                            )}
                        </div>
                    ))
                )}
            </div>
        </div>
    )
}
