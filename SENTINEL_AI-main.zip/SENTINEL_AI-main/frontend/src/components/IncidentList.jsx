import { SEVERITY_COLORS, INCIDENT_STATES } from '../utils/constants'
import './IncidentList.css'

export default function IncidentList({ incidents, onViewDetails, selectedId }) {
    const formatTime = (timestamp) => {
        if (!timestamp) return '-'
        const date = new Date(timestamp)
        return date.toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        })
    }

    const getStateInfo = (state) => {
        return INCIDENT_STATES[state] || { label: state, color: 'var(--text-muted)' }
    }

    return (
        <div className="panel incident-list">
            <div className="panel-header">
                <span className="panel-title">🚨 Active Incidents</span>
                <span className="panel-badge">{incidents.length}</span>
            </div>
            <div className="incident-container">
                {incidents.length === 0 ? (
                    <div className="no-data">No active incidents</div>
                ) : (
                    incidents.map((incident) => {
                        const stateInfo = getStateInfo(incident.state)
                        const isSelected = selectedId === incident.incident_id

                        return (
                            <div
                                key={incident.incident_id}
                                className={`incident-card animate-fade-in ${isSelected ? 'selected' : ''}`}
                                onClick={() => onViewDetails(incident)}
                            >
                                <div className="incident-header">
                                    <span
                                        className="incident-severity"
                                        style={{
                                            background: SEVERITY_COLORS[incident.severity],
                                            boxShadow: `0 0 10px ${SEVERITY_COLORS[incident.severity]}50`
                                        }}
                                    >
                                        {incident.severity}
                                    </span>
                                    <span className="incident-service">{incident.affected_service}</span>
                                    <span className="incident-time">{formatTime(incident.detected_at)}</span>
                                </div>

                                <div className="incident-body">
                                    <div className="incident-symptoms">
                                        {incident.symptoms?.slice(0, 2).map((s, i) => (
                                            <span key={i} className="symptom">{s}</span>
                                        ))}
                                    </div>
                                </div>

                                <div className="incident-footer">
                                    <span
                                        className="incident-state"
                                        style={{
                                            color: stateInfo.color,
                                            borderColor: stateInfo.color
                                        }}
                                    >
                                        <span
                                            className="state-dot"
                                            style={{ background: stateInfo.color }}
                                        ></span>
                                        {stateInfo.label}
                                    </span>
                                    <span className="incident-confidence">
                                        {Math.round((incident.confidence_score || 0) * 100)}% conf.
                                    </span>
                                </div>
                            </div>
                        )
                    })
                )}
            </div>
        </div>
    )
}
