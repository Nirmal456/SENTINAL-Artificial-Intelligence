import { useState, useEffect } from 'react'
import { SEVERITY_COLORS } from '../utils/constants'
import './ApprovalPopup.css'

export default function ApprovalPopup({ incidents, onViewDetails, onApprove, onReject }) {
    const [dismissed, setDismissed] = useState(new Set())

    // Filter for pending approvals that haven't been dismissed
    const pendingApprovals = incidents.filter(
        i => i.state === 'AWAITING_APPROVAL' && !dismissed.has(i.incident_id)
    )

    const handleDismiss = (incidentId) => {
        setDismissed(prev => new Set([...prev, incidentId]))
    }

    const handleView = (incident) => {
        onViewDetails(incident)
        handleDismiss(incident.incident_id)
    }

    const handleApprove = (incident) => {
        onApprove(incident.incident_id)
        handleDismiss(incident.incident_id)
    }

    const handleReject = (incident) => {
        onReject(incident.incident_id, 'Quick reject from popup')
        handleDismiss(incident.incident_id)
    }

    // Play sound when new HIGH/CRITICAL incident appears
    useEffect(() => {
        if (pendingApprovals.length > 0) {
            // Browser notification sound (using Web Audio API)
            try {
                const audioContext = new (window.AudioContext || window.webkitAudioContext)()
                const oscillator = audioContext.createOscillator()
                const gainNode = audioContext.createGain()

                oscillator.connect(gainNode)
                gainNode.connect(audioContext.destination)

                oscillator.frequency.value = 800
                oscillator.type = 'sine'
                gainNode.gain.value = 0.3

                oscillator.start()
                setTimeout(() => {
                    oscillator.stop()
                    audioContext.close()
                }, 200)
            } catch (e) {
                // Audio not supported, skip
            }
        }
    }, [pendingApprovals.length])

    if (pendingApprovals.length === 0) {
        return null
    }

    return (
        <div className="approval-popup-overlay">
            {pendingApprovals.map(incident => (
                <div
                    key={incident.incident_id}
                    className="approval-popup animate-fade-in"
                    style={{ borderLeftColor: SEVERITY_COLORS[incident.severity] }}
                >
                    <div className="popup-header">
                        <span
                            className="popup-severity"
                            style={{ background: SEVERITY_COLORS[incident.severity] }}
                        >
                            🚨 {incident.severity}
                        </span>
                        <span className="popup-service">{incident.affected_service}</span>
                        <button
                            className="popup-close"
                            onClick={() => handleDismiss(incident.incident_id)}
                        >
                            ✕
                        </button>
                    </div>

                    <div className="popup-body">
                        <p className="popup-title">Human Approval Required</p>
                        <p className="popup-message">
                            A {incident.severity} severity incident has been detected in <strong>{incident.affected_service}</strong>.
                            Review the AI diagnosis and decide how to proceed.
                        </p>

                        {incident.symptoms && incident.symptoms.length > 0 && (
                            <div className="popup-symptoms">
                                <span className="symptom-label">Symptoms:</span>
                                <span className="symptom-text">{incident.symptoms[0]}</span>
                            </div>
                        )}
                    </div>

                    <div className="popup-actions">
                        <button
                            className="popup-btn popup-btn-view"
                            onClick={() => handleView(incident)}
                        >
                            View Details
                        </button>
                        <button
                            className="popup-btn popup-btn-approve"
                            onClick={() => handleApprove(incident)}
                        >
                            ✓ Quick Approve
                        </button>
                        <button
                            className="popup-btn popup-btn-reject"
                            onClick={() => handleReject(incident)}
                        >
                            ✕ Reject
                        </button>
                    </div>
                </div>
            ))}
        </div>
    )
}
