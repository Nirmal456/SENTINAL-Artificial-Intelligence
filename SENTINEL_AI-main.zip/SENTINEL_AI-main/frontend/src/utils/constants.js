// Severity and status constants

export const SEVERITY_COLORS = {
    LOW: 'var(--severity-low)',
    MEDIUM: 'var(--severity-medium)',
    HIGH: 'var(--severity-high)',
    CRITICAL: 'var(--severity-critical)'
}

export const LOG_LEVEL_COLORS = {
    INFO: 'var(--log-info)',
    WARNING: 'var(--log-warning)',
    ERROR: 'var(--log-error)',
    CRITICAL: 'var(--log-critical)'
}

export const AGENT_STATUS_COLORS = {
    idle: 'var(--status-idle)',
    processing: 'var(--status-processing)',
    waiting: 'var(--status-waiting)',
    error: 'var(--status-error)'
}

export const INCIDENT_STATES = {
    DETECTED: { label: 'Detected', color: 'var(--accent-primary)' },
    CLASSIFYING: { label: 'Classifying', color: 'var(--accent-secondary)' },
    AUTO_EXECUTING: { label: 'Auto-Executing', color: 'var(--status-processing)' },
    AWAITING_ANALYSIS: { label: 'Analyzing', color: 'var(--status-waiting)' },
    DIAGNOSED: { label: 'Diagnosed', color: 'var(--accent-primary)' },
    AWAITING_APPROVAL: { label: 'Awaiting Approval', color: 'var(--severity-high)' },
    MODIFIED: { label: 'Modified', color: 'var(--status-waiting)' },
    REVALIDATING: { label: 'Revalidating', color: 'var(--accent-secondary)' },
    APPROVED: { label: 'Approved', color: 'var(--status-success)' },
    EXECUTING: { label: 'Executing', color: 'var(--status-processing)' },
    RESOLVED: { label: 'Resolved', color: 'var(--status-success)' },
    FAILED: { label: 'Failed', color: 'var(--status-error)' },
    REJECTED: { label: 'Rejected', color: 'var(--text-muted)' },
    CLOSED: { label: 'Closed', color: 'var(--text-muted)' },
    ESCALATED: { label: 'Escalated', color: 'var(--severity-critical)' }
}

export const SERVICES = [
    'auth-service',
    'api-server',
    'payment-service',
    'worker-service',
    'db'
]
