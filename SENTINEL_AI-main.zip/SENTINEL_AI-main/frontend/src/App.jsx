import { useState } from 'react'
import { useWebSocket } from './hooks/useWebSocket'
import LogStream from './components/LogStream'
import IncidentList from './components/IncidentList'
import IncidentDetails from './components/IncidentDetails'
import AgentObserver from './components/AgentObserver'
import ApprovalPopup from './components/ApprovalPopup'
import ADKChat from './components/ADKChat'
import './App.css'

function App() {
    const {
        isConnected,
        logs,
        incidents,
        agents,
        stats,
        chatMessages,
        approve,
        reject,
        modify,
        chat
    } = useWebSocket()

    const [selectedIncident, setSelectedIncident] = useState(null)
    const [activeTab, setActiveTab] = useState('agents') // 'agents' or 'chat'

    const handleViewDetails = (incident) => {
        setSelectedIncident(incident)
    }

    const handleCloseDetails = () => {
        setSelectedIncident(null)
    }

    return (
        <div className="app">
            {/* Approval Popup for HIGH/CRITICAL incidents */}
            <ApprovalPopup
                incidents={incidents}
                onViewDetails={handleViewDetails}
                onApprove={approve}
                onReject={reject}
            />

            {/* Header */}
            <header className="header">
                <div className="header-brand">
                    <span className="header-logo">🛡️ SENTINEL-AI</span>
                    <span className="header-subtitle">Autonomous Incident Management</span>
                </div>
                <div className={`header-status ${isConnected ? '' : 'disconnected'}`}>
                    <span className="status-dot"></span>
                    <span>{isConnected ? 'Connected' : 'Disconnected'}</span>
                </div>
            </header>

            {/* Main Layout */}
            <main className="main-layout">
                {/* Left Column */}
                <div className="left-column">
                    <LogStream logs={logs} />
                    <IncidentList
                        incidents={incidents}
                        onViewDetails={handleViewDetails}
                        selectedId={selectedIncident?.incident_id}
                    />
                </div>

                {/* Right Column */}
                <div className="right-column">
                    {/* Tab Switcher */}
                    <div className="tab-switcher">
                        <button
                            className={`tab-btn ${activeTab === 'agents' ? 'active' : ''}`}
                            onClick={() => setActiveTab('agents')}
                        >
                            🤖 Agents
                        </button>
                        <button
                            className={`tab-btn ${activeTab === 'chat' ? 'active' : ''}`}
                            onClick={() => setActiveTab('chat')}
                        >
                            💬 ADK Chat
                        </button>
                    </div>

                    {/* Conditional Panel */}
                    {activeTab === 'agents' ? (
                        <AgentObserver agents={agents} />
                    ) : (
                        <ADKChat />
                    )}

                    <IncidentDetails
                        incident={selectedIncident}
                        onApprove={approve}
                        onReject={reject}
                        onModify={modify}
                        onChat={chat}
                        chatMessages={chatMessages}
                        onClose={handleCloseDetails}
                        onSwitchToChat={() => {
                            setActiveTab('chat')
                            setSelectedIncident(null)
                        }}
                    />
                </div>
            </main>

            {/* Stats Footer */}
            <footer className="stats-footer">
                <div className="stat">
                    <span className="stat-value">{stats.total_incidents || 0}</span>
                    <span className="stat-label">Total Incidents</span>
                </div>
                <div className="stat">
                    <span className="stat-value">{stats.auto_executed || 0}</span>
                    <span className="stat-label">Auto-Executed</span>
                </div>
                <div className="stat">
                    <span className="stat-value">{stats.approved || 0}</span>
                    <span className="stat-label">Human Approved</span>
                </div>
                <div className="stat">
                    <span className="stat-value">{stats.rejected || 0}</span>
                    <span className="stat-label">Rejected</span>
                </div>
                <div className="stat">
                    <span className="stat-value">
                        {stats.avg_resolution_time_seconds
                            ? `${Math.round(stats.avg_resolution_time_seconds)}s`
                            : '-'}
                    </span>
                    <span className="stat-label">Avg Resolution</span>
                </div>
            </footer>
        </div>
    )
}

export default App

