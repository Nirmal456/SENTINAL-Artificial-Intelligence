import { useState, useEffect, useRef, useCallback } from 'react'

const WS_URL = 'ws://localhost:8001/ws'

export function useWebSocket() {
    const [isConnected, setIsConnected] = useState(false)
    const [logs, setLogs] = useState([])
    const [incidents, setIncidents] = useState([])
    const [agents, setAgents] = useState([])
    const [stats, setStats] = useState({})
    const [notifications, setNotifications] = useState([])
    const [chatMessages, setChatMessages] = useState({})

    const wsRef = useRef(null)
    const reconnectTimeoutRef = useRef(null)

    const connect = useCallback(() => {
        if (wsRef.current?.readyState === WebSocket.OPEN) return

        try {
            const ws = new WebSocket(WS_URL)
            wsRef.current = ws

            ws.onopen = () => {
                console.log('[WebSocket] Connected')
                setIsConnected(true)
            }

            ws.onclose = () => {
                console.log('[WebSocket] Disconnected')
                setIsConnected(false)
                // Reconnect after 3 seconds
                reconnectTimeoutRef.current = setTimeout(connect, 3000)
            }

            ws.onerror = (error) => {
                console.error('[WebSocket] Error:', error)
            }

            ws.onmessage = (event) => {
                try {
                    const message = JSON.parse(event.data)
                    handleMessage(message)
                } catch (e) {
                    console.error('[WebSocket] Parse error:', e)
                }
            }
        } catch (error) {
            console.error('[WebSocket] Connection error:', error)
            reconnectTimeoutRef.current = setTimeout(connect, 3000)
        }
    }, [])

    const handleMessage = useCallback((message) => {
        const { type, payload } = message

        switch (type) {
            case 'init':
                setAgents(payload.agents || [])
                setIncidents(payload.incidents || [])
                setStats(payload.stats || {})
                break

            case 'log':
                setLogs(prev => [...prev.slice(-99), payload])
                break

            case 'incident':
                setIncidents(prev => [payload, ...prev])
                break

            case 'incident_update':
                setIncidents(prev => prev.map(i =>
                    i.incident_id === payload.incident_id ? payload : i
                ))
                break

            case 'agent_state':
                setAgents(prev => {
                    const idx = prev.findIndex(a => a.agent_name === payload.agent_name)
                    if (idx >= 0) {
                        const updated = [...prev]
                        updated[idx] = payload
                        return updated
                    }
                    return [...prev, payload]
                })
                break

            case 'trace_entry':
                // Could update incident traces if needed
                break

            case 'chat_message':
                setChatMessages(prev => ({
                    ...prev,
                    [payload.incident_id]: [
                        ...(prev[payload.incident_id] || []),
                        payload
                    ]
                }))
                break

            case 'notification':
                setNotifications(prev => [...prev, payload])
                // Auto-clear after 5 seconds
                setTimeout(() => {
                    setNotifications(prev => prev.slice(1))
                }, 5000)
                break

            case 'incident_details':
                // Handle detailed incident data
                break

            case 'agent_states':
                setAgents(payload)
                break

            case 'stats':
                setStats(payload)
                break
        }
    }, [])

    const send = useCallback((type, payload) => {
        if (wsRef.current?.readyState === WebSocket.OPEN) {
            wsRef.current.send(JSON.stringify({ type, payload }))
        }
    }, [])

    const approve = useCallback((incidentId) => {
        send('approve', { incident_id: incidentId })
    }, [send])

    const reject = useCallback((incidentId, reason = '') => {
        send('reject', { incident_id: incidentId, reason })
    }, [send])

    const modify = useCallback((incidentId, modifications) => {
        send('modify', { incident_id: incidentId, modifications })
    }, [send])

    const chat = useCallback((incidentId, message) => {
        send('chat', { incident_id: incidentId, message })
    }, [send])

    const getIncidentDetails = useCallback((incidentId) => {
        send('get_incident', { incident_id: incidentId })
    }, [send])

    useEffect(() => {
        connect()

        return () => {
            if (reconnectTimeoutRef.current) {
                clearTimeout(reconnectTimeoutRef.current)
            }
            if (wsRef.current) {
                wsRef.current.close()
            }
        }
    }, [connect])

    return {
        isConnected,
        logs,
        incidents,
        agents,
        stats,
        notifications,
        chatMessages,
        approve,
        reject,
        modify,
        chat,
        getIncidentDetails
    }
}
