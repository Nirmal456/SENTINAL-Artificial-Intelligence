"""
SENTINEL-AI ADK Agent
Main agent for Google Agent Development Kit integration.
"""
import os
from dotenv import load_dotenv
from google import genai
from google.adk import Agent
from google.adk.tools import FunctionTool

# Load environment variables
load_dotenv()

# Configure Gemini
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyBRotDM7m540yIvrF42i-fB6a8a-wmX7c4")


# Define tools for the agent
def analyze_incident(service: str, severity: str, symptoms: str) -> str:
    """
    Analyze an incident and provide root cause analysis.
    
    Args:
        service: The affected service name (e.g., 'api-server', 'db', 'auth-service')
        severity: The severity level (LOW, MEDIUM, HIGH, CRITICAL)
        symptoms: Description of the observed symptoms
        
    Returns:
        Root cause analysis and recommended remediation steps
    """
    return f"""
## Incident Analysis for {service}

**Severity:** {severity}
**Symptoms:** {symptoms}

### Root Cause Analysis
Based on the symptoms, the likely root cause is:
- Service resource exhaustion
- Cascading failure from upstream dependency
- Configuration drift after recent deployment

### Recommended Remediation
1. Scale up {service} instances
2. Check recent deployments for configuration changes
3. Review upstream service health
4. Enable circuit breaker pattern

### Risk Assessment
- Impact: {"Critical" if severity == "CRITICAL" else "Moderate" if severity == "HIGH" else "Low"}
- Urgency: Immediate action {"required" if severity in ["HIGH", "CRITICAL"] else "recommended"}
"""


def classify_risk(service: str, error_count: int, response_time_ms: int) -> str:
    """
    Classify the risk level of a potential incident.
    
    Args:
        service: The service name
        error_count: Number of errors in the last 5 minutes
        response_time_ms: Average response time in milliseconds
        
    Returns:
        Risk classification with recommendation
    """
    if error_count > 50 or response_time_ms > 5000:
        severity = "CRITICAL"
        action = "HUMAN_APPROVAL_REQUIRED"
    elif error_count > 20 or response_time_ms > 2000:
        severity = "HIGH"
        action = "HUMAN_APPROVAL_REQUIRED"
    elif error_count > 10 or response_time_ms > 1000:
        severity = "MEDIUM"
        action = "AUTO_EXECUTE"
    else:
        severity = "LOW"
        action = "AUTO_EXECUTE"
    
    return f"""
## Risk Classification for {service}

**Error Count:** {error_count}
**Response Time:** {response_time_ms}ms

### Classification
- **Severity:** {severity}
- **Action:** {action}

### Guardrails Applied
- {"Human approval required before execution" if action == "HUMAN_APPROVAL_REQUIRED" else "Safe for auto-remediation"}
"""


def execute_remediation(incident_id: str, action: str) -> str:
    """
    Execute a remediation action (simulated).
    
    Args:
        incident_id: The incident identifier
        action: The remediation action to take
        
    Returns:
        Execution result with status
    """
    return f"""
## Remediation Execution [SIMULATED]

**Incident ID:** {incident_id}
**Action:** {action}

### Execution Log
1. ✓ Validated remediation plan
2. ✓ Acquired necessary permissions
3. ✓ Executed action: {action}
4. ✓ Verified service health

### Result
- **Status:** SUCCESS (SIMULATED)
- **Duration:** 2.3 seconds
- **Rollback Available:** Yes

*Note: This is a simulated execution. In production, actual changes would be applied.*
"""


def get_incident_history(service: str) -> str:
    """
    Get historical incidents for a service.
    
    Args:
        service: The service name to query
        
    Returns:
        Historical incident summary
    """
    return f"""
## Incident History for {service}

### Last 7 Days Summary
| Date | Severity | Root Cause | Resolution Time |
|------|----------|------------|-----------------|
| Today | LOW | Cache miss spike | 45s (auto) |
| Yesterday | MEDIUM | DB connection pool | 3m (auto) |
| 3 days ago | HIGH | Memory leak | 15m (manual) |

### Patterns Detected
- Peak incident times: 9-11 AM UTC
- Common root cause: Resource exhaustion
- Avg resolution time: 4.2 minutes

### Recommendations
- Increase connection pool size
- Add memory monitoring alerts
- Consider horizontal scaling
"""


# Create the SENTINEL-AI Agent
root_agent = Agent(
    name="sentinel_ai",
    model="gemini-2.0-flash-lite",
    description="""SENTINEL-AI: Autonomous Incident Management System

I am an AI-powered SRE assistant that helps manage production incidents. I can:
- Analyze incidents and identify root causes
- Classify risk levels and apply appropriate guardrails
- Execute remediation actions (with human approval for HIGH/CRITICAL)
- Learn from historical incident patterns

I follow strict guardrails:
- LOW/MEDIUM severity: Auto-execute remediation
- HIGH/CRITICAL severity: Require human approval before execution""",
    instruction="""You are SENTINEL-AI, an autonomous incident management agent.

Your responsibilities:
1. When asked about an incident, use analyze_incident to provide root cause analysis
2. Use classify_risk to determine severity and whether human approval is needed
3. Only use execute_remediation after confirming human approval for HIGH/CRITICAL incidents
4. Use get_incident_history to learn from past incidents

CRITICAL GUARDRAILS:
- NEVER auto-execute remediation for HIGH or CRITICAL severity without explicit human approval
- ALWAYS explain your reasoning before taking action
- Prefer safe, reversible actions over risky ones
- When in doubt, ask for human guidance""",
    tools=[
        FunctionTool(analyze_incident),
        FunctionTool(classify_risk),
        FunctionTool(execute_remediation),
        FunctionTool(get_incident_history),
    ]
)
