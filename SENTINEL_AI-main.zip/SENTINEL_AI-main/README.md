# 🛡️ SENTINEL-AI

**Autonomous Incident Management System with Multi-Agent AI**

SENTINEL-AI is an intelligent SRE platform that autonomously detects, analyzes, and remediates production incidents using an 8-agent swarm architecture powered by Google Gemini 2.0 Flash Lite.

---

## 🎯 Key Features

### 🤖 8-Agent Autonomous System
- **LogWatcher** - Generates realistic production logs
- **IncidentDetector** - Detects anomalies in real-time
- **RiskClassifier** - Classifies severity (LOW/MEDIUM/HIGH/CRITICAL)
- **Planner** - Creates remediation plans using AI
- **Approval** - Human-in-the-loop for HIGH/CRITICAL incidents
- **Executor** - Executes remediation (simulated mode)
- **Memory** - Learns from past incidents
- **Chat** - Conversational AI for incident analysis

### 📱 Multi-Channel Alerting
- **WhatsApp** - Instant alerts via Twilio for CRITICAL incidents
- **Email** - Professional HTML emails with incident details
- **Dashboard** - Real-time WebSocket updates

### 💬 ADK Chat Integration
- Conversational AI powered by Google Gemini
- Ask questions about incidents, services, and remediation
- Tool usage indicators (analyze, classify, execute)
- Seamless tab switching from incident details

### 🎨 Premium UI/UX
- Real-time incident dashboard
- Agent activity observer
- Approval workflow with modify/reject options
- Dark theme with glassmorphism effects
- Responsive design

---

## 🏗️ Architecture
<img width="787" height="767" alt="Screenshot 2026-01-24 232438" src="https://github.com/user-attachments/assets/d53bc232-d67f-4ce5-9741-323aa6f7fbd0" />

```
┌─────────────────────────────────────────────────────────────┐
│                     SENTINEL-AI System                       │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │ LogWatcher   │───▶│   Incident   │───▶│     Risk     │  │
│  │   Agent      │    │   Detector   │    │  Classifier  │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│                                                    │          │
│                                                    ▼          │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   Memory     │◀───│   Executor   │◀───│   Planner    │  │
│  │   Agent      │    │    Agent     │    │    Agent     │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│                              │                    │          │
│                              ▼                    ▼          │
│                      ┌──────────────┐    ┌──────────────┐  │
│                      │   Approval   │    │     Chat     │  │
│                      │    Agent     │    │    Agent     │  │
│                      └──────────────┘    └──────────────┘  │
│                              │                               │
│                              ▼                               │
│                    ┌──────────────────┐                     │
│                    │  Notifications   │                     │
│                    │ WhatsApp + Email │                     │
│                    └──────────────────┘                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start

### Prerequisites
- Python 3.10+
- Node.js 18+
- Google Gemini API Key (with billing enabled)
- Twilio Account (for WhatsApp)
- Gmail Account (for email alerts)

### 1. Clone Repository
```bash
git clone <your-repo-url>
cd Hackathonnn
```

### 2. Backend Setup

#### Install Dependencies
```bash
cd backend
pip install -r requirements.txt
```

#### Configure Environment Variables
Create `backend/.env`:
```env
# Gemini API
GEMINI_API_KEY=your_gemini_api_key_here
USE_MOCK_LLM=false

# System Config
LOG_INTERVAL_SECONDS=2
WEBSOCKET_PORT=8001
EXECUTION_MODE=simulated

# WhatsApp Alerts (Twilio)
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
ALERT_WHATSAPP_TO=whatsapp:+91XXXXXXXXXX

# Email Alerts (Gmail)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_app_password
ALERT_EMAIL_TO=admin@company.com
```

#### Run Backend
```bash
python main.py
```

### 3. Frontend Setup

#### Install Dependencies
```bash
cd frontend
npm install
```

#### Run Frontend
```bash
npm run dev
```

### 4. ADK Setup (Optional)

#### Configure ADK
Create `my_agent/.env`:
```env
GOOGLE_API_KEY=your_gemini_api_key_here
GOOGLE_GENAI_USE_VERTEXAI=false
```

#### Run ADK Web
```bash
python -m google.adk.cli web
```

---

## 🔧 Configuration Guide

### ⚠️ IMPORTANT: Gemini API Key Must Be Updated in 3 Places!

The Gemini API key is used by multiple services and must be configured in **all 3 locations**:

1. **`backend/.env`** - For the main backend agents
2. **`my_agent/.env`** - For the ADK agent
3. **`my_agent/agent.py`** - Fallback value in code (line 15)

**Steps to configure:**

#### 1. Get Your API Key
1. Go to https://aistudio.google.com/apikey
2. Create API key in new project
3. **Enable billing** for production use (required for Gemini 2.0 Flash Lite)
4. Copy the API key

#### 2. Update `backend/.env`
```env
GEMINI_API_KEY=your_gemini_api_key_here  # ← Update this
USE_MOCK_LLM=false
```

#### 3. Update `my_agent/.env`
```env
GOOGLE_API_KEY=your_gemini_api_key_here  # ← Update this
GOOGLE_GENAI_USE_VERTEXAI=false
```

#### 4. Update `my_agent/agent.py` (line 15)
```python
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "your_gemini_api_key_here")  # ← Update fallback
```

> **💡 Pro Tip:** Use the same API key in all 3 places to avoid confusion!

### Twilio WhatsApp
1. Sign up at https://www.twilio.com/try-twilio
2. Go to WhatsApp Sandbox: https://console.twilio.com/us1/develop/sms/try-it-out/whatsapp-learn
3. Send "join <sandbox-code>" to +1 415 523 8886 from WhatsApp
4. Copy Account SID and Auth Token to `backend/.env`

### Gmail SMTP
1. Enable 2FA on Google account
2. Create App Password: https://myaccount.google.com/apppasswords
3. Copy 16-character password to `backend/.env`

---

## 📊 Demo Flow

### 1. System Startup
```bash
# Terminal 1: Backend
cd backend && python main.py

# Terminal 2: Frontend
cd frontend && npm run dev

# Terminal 3: ADK Web (optional)
python -m google.adk.cli web
```

### 2. Access Dashboard
- **Main Dashboard**: http://localhost:5173
- **ADK Web**: http://localhost:8000
- **Backend API**: http://localhost:8001

### 3. Observe Incidents
1. Watch real-time log generation
2. See incidents detected automatically
3. Observe risk classification
4. View agent activity in real-time

### 4. Test Approval Workflow
1. Wait for HIGH/CRITICAL incident
2. Approval popup appears
3. Options: Approve / Modify / Reject
4. WhatsApp + Email alerts sent

### 5. Use ADK Chat
1. Click "💬 ADK Chat" tab
2. Ask: "What's the status of the payment service?"
3. See AI analysis with tool usage
4. Get incident history and recommendations

---

## 🎨 Features Showcase

### Autonomous Remediation
- **LOW/MEDIUM**: Auto-executed within seconds
- **HIGH/CRITICAL**: Human approval required
- **Guardrails**: Safety checks prevent destructive actions

### Multi-Channel Alerts
- **WhatsApp**: Instant mobile notifications
- **Email**: Professional HTML emails with details
- **Dashboard**: Real-time WebSocket updates

### AI-Powered Analysis
- **Root Cause**: Gemini analyzes symptoms
- **Risk Assessment**: Severity classification
- **Remediation Plans**: AI-generated solutions
- **Learning**: Memory agent stores patterns

### Premium UI
- **Dark Theme**: Professional SRE aesthetic
- **Glassmorphism**: Modern design effects
- **Animations**: Smooth transitions
- **Responsive**: Works on all devices

---

## 🛠️ Tech Stack

### Backend
- **FastAPI** - High-performance async API
- **WebSocket** - Real-time updates
- **Google Gemini 2.0 Flash Lite** - AI analysis
- **Twilio** - WhatsApp integration
- **Gmail SMTP** - Email alerts

### Frontend
- **React** - UI framework
- **Vite** - Build tool
- **CSS Variables** - Theming
- **WebSocket** - Real-time data

### AI/ML
- **Google ADK** - Agent Development Kit
- **Gemini 2.0 Flash Lite** - LLM (50% cheaper than Flash)
- **Function Calling** - Tool usage

---

## 📁 Project Structure

```
Hackathonnn/
├── backend/
│   ├── agents/          # 8 autonomous agents
│   ├── services/        # LLM, notifications, ADK chat
│   ├── websocket/       # Real-time communication
│   ├── main.py          # FastAPI server
│   └── .env             # Configuration
├── frontend/
│   ├── src/
│   │   ├── components/  # React components
│   │   ├── hooks/       # WebSocket hook
│   │   └── App.jsx      # Main app
│   └── package.json
├── my_agent/
│   ├── agent.py         # ADK agent definition
│   └── .env             # ADK configuration
└── README.md
```

---

## 🎯 Hackathon Highlights

### Innovation
- **8-agent swarm** working in concert
- **Human-in-the-loop** safety guardrails
- **Multi-channel alerting** (WhatsApp + Email)
- **Conversational AI** for incident analysis

### Technical Excellence
- **Real-time architecture** with WebSocket
- **Async/await** throughout for performance
- **Type safety** with Pydantic models
- **Error handling** and graceful degradation

### User Experience
- **Premium UI** with animations
- **Intuitive workflows** for SRE teams
- **Mobile-first** notifications
- **Accessibility** considerations

### Scalability
- **Modular agent architecture**
- **Configurable severity thresholds**
- **Mock mode** for testing
- **Production-ready** error handling

---

## 🔒 Security & Safety

### Guardrails
- **Severity-based approval**: HIGH/CRITICAL require human approval
- **Simulated execution**: No actual infrastructure changes
- **Audit trail**: All actions logged
- **Memory learning**: Patterns stored for future incidents

### Best Practices
- **Environment variables**: Sensitive data in `.env`
- **API key rotation**: Easy to update
- **Rate limiting**: Respects API quotas
- **Error handling**: Graceful failures

---

## 📈 Future Enhancements

- [ ] Integration with real monitoring tools (Prometheus, Datadog)
- [ ] Kubernetes operator for auto-scaling
- [ ] Slack integration
- [ ] Custom playbook editor
- [ ] Multi-tenant support
- [ ] Advanced analytics dashboard
- [ ] Mobile app

---

## 👥 Team

Built for [Hackathon Name] by [Your Team Name]

---

## 📄 License

[Your License Here]

---

## 🙏 Acknowledgments

- Google Gemini API
- Twilio WhatsApp API
- React & Vite communities
- FastAPI framework

---

**Made with ❤️ for autonomous incident management**
